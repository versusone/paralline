## This file is part of the Software: paralline.
## This file and paralline are provided under the MIT licence:
## The MIT Licence can be found at: https://tldrlegal.com/license/mit-license#fulltext
## and in the file LICENCE.txt of the current directory of the software.
##
## Copyright (c) 2007-2008, Patrick Germain Placidoux
## All rights reserved.
##
## Permission is hereby granted, free of charge, to any person obtaining a copy
## of this software and associated documentation files (the "Software"), to deal
## in the Software without restriction, including without limitation the rights
## to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
## copies of the Software, and to permit persons to whom the Software is
## furnished to do so, subject to the following conditions:
##
## The above copyright notice and this permission notice shall be included in all
## copies or substantial portions of the Software.
##
## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
## IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
## FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
## AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
## LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
## OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
## SOFTWARE.
##
##  @author: Patrick Germain Placidoux
##  @contact: paralline@gmx.com



""" 
Maybe sometimes like me, you wondered how to enter complexes Python types, 
straight from the command line.
   
CoolTyping comes for this purpose
of dealing with basics and complexes types typed from a command line or a string.

CoolTyping can be compared to a lite serialisation mechanism,
so working in two directions :
    _ from a string representation to a Python representation.
    _ from a Python representation to a string representation.

example
-------

    From a Python representation to a string representation :

        The Python representation of a list is :
            ['this', 'is', 'a', 'list']
            
        The CoolTyped representation of the list is :
            '[this,is,a,list]'
            
        CoolTyping get rid of accessories,
        that is the reason why the method (or function) of this operation is called unDress.
        The complete example is :

        >> from konflib.tools import CoolTyping as ct #this line won't be repeated in the next examples
        >> l=['this', 'is', 'a', 'list']
        >> print ct.unDress(l)
        [this,is,a,list]


    From a string representation to a Python representation.    

        >> print ct.dress('[this,is,a,list]')
        ['this', 'is', 'a', 'list']
    
    
    Spaces are significative CoolTyping supports spaces in the both directions
    
        >> l=[' this ','  is  ' ,'a','    list    ']
        >> ct.unDress(l)
        '[ this ,  is  ,a,    list    ]'
        >> s=ct.unDress(l)
        >> ct.dress(s)
        [' this ', '  is  ', 'a', '    list    ']
        >> ct.dress(s)==l
        True
        >>


CoolTyping supported types are :
    str, int, long, float, bool, tuple, list, dict, date (*), ts (*)


str CoolTyping
==============
'this is a string'  --> 'this is a string'
                    <--
No change


bool CoolTyping
===============
True    -->     'True'
        <--


tuple CoolTyping
================
('this', 'is', 'a', 'tuple')    -->     (this,is,a,tuple)
                                <--


list CoolTyping
===============
['this', 'is', 'a', 'list']     -->     [this,is,a,list]
                                <--


dict CoolTyping
===============
{'kind':'dog', 'fly':False, 'color':'brown', 'number':2}
<--
-->
{fly:False,color:brown,kind:dog,number:2}



CoolTyping is recursive :

['this', 'is', 'a', 'list with a dict', {'kind':'dog', 'fly':False, 'color':'brown', 'number':2}]
<--
-->
[this,is,a,list with a dict,{fly:False,color:brown,kind:dog,number:2}]


CoolTyping works with wk
    For more information see the docstring of the wk class,
    or from a command line type: doc.py apy.tools.wk.

* : futures versions.

WARNING:
========
Since Python 2.6 integer expressions starting with 0 are interpreted as octal,
octal greater than 07 mean nothing and eval will fail:
Try this into python interpreter:
eval('08')
So do not pass CoolTyped expression with integer with a leading 0 !
"""

import ctexception


#-----------------#
#  Protected eval #
#-----------------#

def _eval(value):
    selfMethod='_eval'
    ALLOWED_TYPES=('None', 'False', 'True', 'str', 'int', 'float', 'bool', 'tuple', 'list', 'dict')
    builtins={}
    
    try:
        for typ in ALLOWED_TYPES:builtins[typ]=__builtins__[typ]

        res=eval(value, {"__builtins__": builtins})
    except:
        import sys
        raise ctexception.ctSystemException('Echec trying to evaluate:' + str(value) + '. SubException:' + str(sys.exc_info()[0]) + ' ' + str(sys.exc_info()[1]), fromClass='Main', fromMethod=selfMethod)
    return res


#--------------#
#  CoolTyping  #
#--------------#
    
ESCAPE_CAR ='~'

def dress(st):
    selfMethod='dress'
    if not isinstance(st, str) :raise ctexception.ctParameterTypeException('st', 'str', str(st), fromClass='CoolTyping', fromMethod=selfMethod)                  
                    
    """
    {attr1:value1,attr2:value2,attr3:value3,attr4:(value1,value2,value3,value4,value5),attr5:value5,attr6:value6}
    """      
    
    st=st.strip()
    import re 

    ## 1 Treat escape caracter forward
    dl=backSlach(st, ((',', '&eacute_virg'), (':', '&eacute_dble'), ('(', '&eacute_left1'), (')', '&eacute_right1'), ('[', '&eacute_left2'), (']', '&eacute_right2'), ('{', '&eacute_left3'), ('}', '&eacute_right3')))
    
    ## 2 Stick "" everywhere
    dl=re.sub(r'([^:^,^\{^\}^\(^\)^\[^\]]+)', r'"\1"', dl)
    
    ## 3 Treat escape caracter backward
    dl=unBackSlach(dl, ((',', '&eacute_virg'), (':', '&eacute_dble'), ('(', '&eacute_left1'), (')', '&eacute_right1'), ('[', '&eacute_left2'), (']', '&eacute_right2'), ('{', '&eacute_left3'), ('}', '&eacute_right3')))
    
    ## 3 Get rid of "" for: True/False, None, Numeric
    # True/False:
    dl=re.sub(r'"(True)"', r"\1", dl)
    dl=re.sub(r'"(False)"', r"\1", dl)
    # None:
    dl=re.sub(r'"(None)"', r"\1", dl)
    # Numeric:
    # Support Negative int
    dl=re.sub(r'"([-]*[0-9]+\.{0,1}[0-9]*)"', r"\1", dl)
    dl=_eval(dl)
    
    return dl

def unDress(dl):
    selfMethod='unDress'
    ALLOWED_TYPES=(tuple, list, dict)

    if not isinstance(dl, tuple) and not isinstance(dl, list) and not isinstance(dl, dict):return str(dl)

    ## Protect caller
    if isinstance(dl, dict):dl=dict(dl)
    if isinstance(dl, tuple):dl=tuple(dl)
    if isinstance(dl, list):dl=list(dl)
    
    ##  Treat escape caracter
    # dl is tuple or list:
    if isinstance(dl, tuple) or isinstance(dl, list):            
        if isinstance(dl, tuple):_dl=list(dl)
        else:_dl=dl
        for i in range(len(_dl)):
            if isinstance(_dl[i], str):
                import re                    
                r="r'" + ESCAPE_CAR  + "\\1'"
                # ex: ok:#_dl[i]=re.sub(r'([:,\{\}\(\)\[\]])', r'~\1', _dl[i])
                _dl[i]=re.sub(r'([:,\{\}\(\)\[\]])', _eval(r), _dl[i])
            else:_dl[i]=unDress(_dl[i])
        if isinstance(dl, tuple):dl=tuple(_dl)
        
    # dl is dict:
    # ex: d={thread:$Thread,format:(%(asctime)s,%(levelname)s,%(process)d,%(message)s)}
    else:
        for key in list(dl.keys()):
            if isinstance(dl[key], str):
                if dl[key]=='' or dl[key]==len(dl[key])*' ':
                    dl[key]=None
                    continue

                import re
                r="r'" + ESCAPE_CAR  + "\\1'"
                 # ex: dl[key]=re.sub(r'([:,\{\}\(\)\[\]])', r'~\1', dl[key])
                dl[key]=re.sub(r'([:,\{\}\(\)\[\]])', _eval(r), dl[key])
                                    
            else:dl[key]=unDress(dl[key])
    st=str(dl)        

    import re 
    st=re.sub(r'\'|"', r"", st)

    ## Treat spaces arround escape caracter
    # ex: dl={"a b  c    d  fg":'x yz', 'b':23}
    st=re.sub("([:,]+)\s", r"\1", st)
    return st
        
def backSlach(st, lst):
    for tp in lst:
        source, target = tp
        source=ESCAPE_CAR + source              
        st=st.replace(source, target)
    return st                
        
def unBackSlach(st, lst):
    for tp in lst:
        source, target = tp            
        st=st.replace(target, source)
    return st