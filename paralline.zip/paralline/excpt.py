## This file is part of the Software: paralline.
## This file and paralline are provided under the MIT licence:
## The MIT Licence can be found at: https://tldrlegal.com/license/mit-license#fulltext
## and in the file LICENCE.txt of the current directory of the software.
##
## Copyright (c) 2007-2008, Patrick Germain Placidoux
## All rights reserved.
##
## Permission is hereby granted, free of charge, to any person obtaining a copy
## of this software and associated documentation files (the "Software"), to deal
## in the Software without restriction, including without limitation the rights
## to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
## copies of the Software, and to permit persons to whom the Software is
## furnished to do so, subject to the following conditions:
##
## The above copyright notice and this permission notice shall be included in all
## copies or substantial portions of the Software.
##
## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
## IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
## FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
## AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
## LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
## OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
## SOFTWARE.
##
##  @author: Patrick Germain Placidoux
##  @contact: paralline@gmx.com



"""
--------------------
| Paralline Errors |
--------------------
"""

class ParallineError(Exception):
    def __init__(self, fromClass=None, fromMethod=None):
        # python bug (>2.4<=2.6.5), only concern Exception classes: (c)pickle needs proper super class init.
        Exception.__init__(self, '')

        self.fromClass = fromClass
        self.fromMethod = fromMethod
        if self.fromClass != None and self.fromMethod != None:
            self.fromWhere = "From Class: " + self.fromClass + "  Method: " + self.fromMethod + ", "
        else:self.fromWhere = ""

class ParallineParameterTypeError(ParallineError):

    def __init__(self, p_parmName, p_parmTypeExpected, p_parmTypeReceived, fromClass=None, fromMethod=None):
        ParallineError.__init__(self, fromClass, fromMethod)
        self.parmName = p_parmName
        self.parmTypeExpected=p_parmTypeExpected
        self.parmTypeReceived=p_parmTypeReceived

    def __reduce__(self):
        return ( ParallineParameterTypeError, (self.parmName, self.parmTypeExpected, self.parmTypeReceived, self.fromClass, self.fromMethod) )

    def __str__(self):
        return self.fromWhere + "Received Bad pamameter type for: " + self.parmName  + \
          ". Type Expected: " + str(self.parmTypeExpected) + \
          ". Type Received: " + str(self.parmTypeReceived)

class ParallineParameterError(ParallineError):

    def __init__(self, p_parmName, p_why, fromClass=None, fromMethod=None):
        ParallineError.__init__(self, fromClass, fromMethod)
        self.parmName = p_parmName
        self.parmwhy=p_why

    def __reduce__(self):
        return ( ParallineParameterError, (self.parmName, self.parmwhy, self.fromClass, self.fromMethod) )

    def __str__(self):
        return self.fromWhere + "Received Bad pamameter for: " + self.parmName  + \
          ". Reason: " + str(self.parmwhy)

class ParallineSystemError(ParallineError):

    def __init__(self, p_why, fromClass=None, fromMethod=None):
        ParallineError.__init__(self, fromClass, fromMethod)
        self.parmwhy=p_why

    def __reduce__(self):
        return ( ParallineSystemError, (self.parmwhy, self.fromClass, self.fromMethod) )

    def __str__(self):
        return self.fromWhere + str(self.parmwhy)

class ParallineResourceLockError(ParallineError):

    def __init__(self, p_resource, fromClass=None, fromMethod=None):
        ParallineError.__init__(self, fromClass, fromMethod)
        self.resource=p_resource

    def __reduce__(self):
        return ( ParallineResourceLockError, (self.resource, self.fromClass, self.fromMethod) )

    def __str__(self):
        return self.fromWhere + "The resource " + self.resource + " is not available" + \
        " for the asker : " +  self.sadOne + \
        " beeing locked by : " +  self.luckyOne


class ParallineEndLineNotFoundError(ParallineError):

    def __init__(self, separator=None, line_max_size=None, file=None, position=None, fromClass=None, fromMethod=None):
        ParallineError.__init__(self, fromClass, fromMethod)
        self.separator = separator
        self.line_max_size = line_max_size
        self.file = file
        self.position = position

    def __reduce__(self):
        return ( ParallineEndLineNotFoundError, (self.separator, self.line_max_size, self.fromClass, self.fromMethod) )

    def __str__(self):
        import paralline
        return self.fromWhere + r"Unable to find end of line with separator: {separator} within the range of line_size: {line_max_size} for file: {file} at position: {position}. This shunk is skipped.\nSee the foolowing Help on \"line_max_size\":\n{help}".format(separator = self.separator, line_max_size = self.line_max_size, file = self.file, position = self.position, help = paralline.HELP_LINE_MAX_SIZE)


"""
-----------------
| Worker Errors |
-----------------
"""

class WorkerParameterTypeError(ParallineError):

    def __init__(self, p_parmName, p_parmTypeExpected, p_parmTypeReceived, fromClass=None, fromMethod=None):
        ParallineError.__init__(self, fromClass, fromMethod)
        self.parmName = p_parmName
        self.parmTypeExpected=p_parmTypeExpected
        self.parmTypeReceived=p_parmTypeReceived

    def __reduce__(self):
        return ( WorkerParameterTypeError, (self.parmName, self.parmTypeExpected, self.parmTypeReceived, self.fromClass, self.fromMethod) )

    def __str__(self):
        return self.fromWhere + "Received Bad pamameter type for: " + self.parmName  + \
          ". Type Expected: " + str(self.parmTypeExpected) + \
          ". Type Received: " + str(self.parmTypeReceived)

class WorkerParameterError(ParallineError):

    def __init__(self, p_parmName, p_why, fromClass=None, fromMethod=None):
        ParallineError.__init__(self, fromClass, fromMethod)
        self.parmName = p_parmName
        self.parmwhy=p_why

    def __reduce__(self):
        return ( WorkerParameterError, (self.parmName, self.parmwhy, self.fromClass, self.fromMethod) )

    def __str__(self):
        return self.fromWhere + "Received Bad pamameter for: " + self.parmName  + \
          ". Reason: " + str(self.parmwhy)

class WorkerSystemError(ParallineError):

    def __init__(self, p_why, fromClass=None, fromMethod=None):
        ParallineError.__init__(self, fromClass, fromMethod)
        self.parmwhy=p_why

    def __reduce__(self):
        return ( WorkerSystemError, (self.parmwhy, self.fromClass, self.fromMethod) )

    def __str__(self):
        return self.fromWhere + str(self.parmwhy)

class QueueRequestMonitorError(ParallineError):

    def __init__(self, p_why, fromClass=None, fromMethod=None):
        ParallineError.__init__(self, fromClass, fromMethod)
        self.parmwhy=p_why

    def __reduce__(self):
        return ( QueueRequestMonitorError, (self.parmwhy, self.fromClass, self.fromMethod) )

    def __str__(self):
        return self.fromWhere + str(self.parmwhy)

class QueueResponseMonitorError(ParallineError):

    def __init__(self, p_why, fromClass=None, fromMethod=None):
        ParallineError.__init__(self, fromClass, fromMethod)
        self.parmwhy=p_why

    def __reduce__(self):
        return ( QueueRequestMonitorError, (self.parmwhy, self.fromClass, self.fromMethod) )

    def __str__(self):
        return self.fromWhere + str(self.parmwhy)

class QueueRequestNewTaskError(ParallineError):

    def __init__(self, p_why, fromClass=None, fromMethod=None):
        ParallineError.__init__(self, fromClass, fromMethod)
        self.parmwhy=p_why

    def __reduce__(self):
        return ( QueueRequestMonitorError, (self.parmwhy, self.fromClass, self.fromMethod) )

    def __str__(self):
        return self.fromWhere + str(self.parmwhy)

class UserFunctionError(ParallineError):

    def __init__(self, p_why, fromClass=None, fromMethod=None):
        ParallineError.__init__(self, fromClass, fromMethod)
        self.parmwhy=p_why

    def __reduce__(self):
        return ( UserFunctionError, (self.parmwhy, self.fromClass, self.fromMethod) )

    def __str__(self):
        return self.fromWhere + str(self.parmwhy)
