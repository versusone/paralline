## This file is part of the Software: paralline.
## This file and paralline are provided under the MIT licence:
## The MIT Licence can be found at: https://tldrlegal.com/license/mit-license#fulltext
## and in the file LICENCE.txt of the current directory of the software.
##
## Copyright (c) 2007-2008, Patrick Germain Placidoux
## All rights reserved.
##
## Permission is hereby granted, free of charge, to any person obtaining a copy
## of this software and associated documentation files (the "Software"), to deal
## in the Software without restriction, including without limitation the rights
## to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
## copies of the Software, and to permit persons to whom the Software is
## furnished to do so, subject to the following conditions:
##
## The above copyright notice and this permission notice shall be included in all
## copies or substantial portions of the Software.
##
## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
## IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
## FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
## AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
## LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
## OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
## SOFTWARE.
##
##  @author: Patrick Germain Placidoux
##  @contact: paralline@gmx.com



"""
--------
| Help |
--------

>>> import paralline
>>> help(paralline.Paralline)
>>> help(Paralline)

----------------
| What it does |
----------------

Reads a directory (or a set of files) and parse all the lines over multiple processes.
Processes receive the lines, run the same script overs those lines
and return their results as an iterable.
Paralline manages these processes and aggregates their results into an iterable
and returns it.


Files:
------
Paralline is designed to run multi Gigabytes long text files.
These files are supposed to have the same schema.
What we call a line is an amount of text data delimited by a separator.
These files can be any semi-structured files like:
    log files, json files, .csv, or xml files for instance.
Or any kind of text files that separates contents by the same separator (not need to be \n the default).


Script:
-------
1/ When run externally as a command

The option: -f (--script_file) is used.
e.g.: python3 paralline.py /where/is/my/text_file  -f /where/is/my/python_file.py

Each Process runs the same script.
This script is a Python file.
This Python file must support the following Function:
def digest(lines):
    <do something>

    return lines # or any iterable or None

This Function may return an iterable or None.
If all calls return None, Paralline would return an empty list.

2/ When run internally as an instance of the Paralline class,

The parameter: fct is used.
e.g.: paralline = Paralline()
      result_list = paralline.x(r'/where/is/my/text_file1', r'/where/is/my/text_file2', r'/or/a/directory', ..., fct=list(map(lambda lines:lines)))

"x" is an alias for the function "execute".
Here this lambda just returns lines
Script file could be a Python file like above.

But preferably it is a Python function.
It can be a lambda function or any Python (def) function.
This function must support one argument: lines.
> Because the function is serialized the Python Package: "dill" must be installed.


Processes:
----------
One can define the number of processes to run,
but by default Paralline would run as much processes as there are cores on the machine.


------------------
| How it does it |
------------------

No matter what the size of a file is,
Paralline splits the files in packet of lines of same size (shunk-size) as much as possible.
Each packet ends boundary, by a legitimate separator.

Note:
-----
a) The default separator is "\n" but it can be provided as a command option "-l" (or "--line_separator").
Or as a parameter: "line_separator" of the function "x" of the Paralline instance.
b) If Paralline cannot reach the end of the line with the range of "line_max_size" (default 1m),
it tries to go to the end of the file.
But it will raise a Warning:
    ParalleleEndLineNotFoundWarning:Contracts:ajustEnd: File: <file_name> => Unable to seek line separator from end: 1234 within line_max_size: 1M !
    You should considere to increase line_max_size.
This is explicite: either you wrong and you provided a bad "line_separator" that doesn't exist in the file,
or line_max_size is not big enought !

A packet may be built of many lines spreaded over one or multiple files.

Actually in Paralline a Packet is a definition that lives within a "contract".
A "contract" defines the disk offset of the first and the last line of the packet.
A "contract" also defines the files where the lines come from.
In a packet they are as many line that are need to reach shunk_size.

Contracts are equally (as much possible) distributed over processes.

- processes iterates over their set of contracts.
- processes read from the files as many lines need for the contract and operate the lines
into the regular funtion.
- The function returns an iterable or None.
- This iterable is streamed up to the Paralline manager which extends it up to the main list.
- The main list is returned by the "x" function.

> Because each process reads the same file system as they access randomly to the set of files,
they must share the same FS.
> This point is a landmark for the future version which plans to support remote worker.


Examples:
---------
Into the Paralline directory they are too couple of files:
- test1.txt and test.py
- test2.txt and test2.py
$> cd <paralline_dir>

a) To run them on command line:
python3 paralline.py test1.txt -f test1.py

b) To run them in Python interpreter:
$> python3
>>> from paralline import Paralline
>>> paralline = Paralline()
>>> paralline.x(test1.txt, fct=test1.py)
or
>>> paralline.x(test1.txt, fct=list(map(lambda lines:lines)))

e.g.: If you run this:
python3 paralline.py test1.txt  -f test1.py -d
You would see this:

Result Lines:
-------------
1 Lorem ipsum dolor sit amet, consectetur adipiscing elit,
2 sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
3 Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
4  aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit
5   esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
6    sunt in culpa qui officia deserunt mollit anim id est laborum
7     Lorem ipsum dolor sit amet, consectetur adipiscing elit,
8      sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
9 Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut1
10  aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit
11   esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
12    sunt in culpa qui officia deserunt mollit anim id est laborum
13     Lorem ipsum dolor sit amet, consectetur adipiscing elit,
14      sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
15 Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
16    aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit
17  esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
18 sunt in culpa qui officia deserunt mollit anim id est laborum

Lines Count: 19



Default:
--------
Default values are in the file named "paralline.attrs" into the paralline directory.


----------------
| How it works | You don't need to read this
----------------

1/ Launches the QDealer on Host Port.
The QDealer deals queues to the worker processes (that's it).
The Paralline manager and worker processes communicate via Multiprocessing queues.

2/ Redirects Outputs and logs to the Paralline manager.

3/ Tries to Launch as many Workers as required by the "parallele" parameter.

4/ Calculation and Adjustment
-----------------------------
a) Obtains the total files size:
Reads the size of all files from the set of files or
the provided directory (eventually with the provided prefixes/suffixes).
Sums up all these sizes and obtains : "total_files_size" the total amount of bytes for the whole files.

b) Obtains the total size for one unit of work:
Divides this "total_files_size" per "proc_parallele" and obtains "uow_total_size": the total amount of bytes per process.

c/ Adjusts shunk_size (Safe guard):
-----------------------------------
if uow_total_size is lesser than  shunk_size than uow_total_size/2 becomes shunk_size.
if uow_total_size is greater than shunk_size than shunk_size is kept.


5/ Run Payload on all Workers and Join.
Process receive as much contracts as need to fill up uow_total_size.
"contract" must not be bigger than "shunk_size".
"""


MEMORY_SYNTAX='<memory>G|<memory>M'
HELP_LINE_MAX_SIZE = "The Maximum size of a line.\n\
At the end of each shunk, the line separator is searched to mark the end of a shunk line boundary, with the end of a valid line.\n\
Paralline will search for this separator within the range of: line_max_size.\n\
If the \"line_separator\" is not find in this range a ParalleleEndLineNotFoundWarning will be raised !\n\
If a warning ParalleleEndLineNotFoundWarning is raised you may choose to increase the size of line_max_size."

from os import path
import warnings
import threading
import tools
from tools import pprint
import random
random.seed()
import excpt
import workers
import preferences

from queue import Empty
from multiprocessing.managers import BaseManager
class QueueManager(BaseManager):pass
QueueManager.register('get_perm_queue')
QueueManager.register('del_perm_queue')
QueueManager.register('get_temp_queue')
QueueManager.register('get_qmanager')
QDEALER = None
SERVER_UID = None

TIME_REQUIRED_BY_LAYER_NOT_TO_MISS_PACKET = 2



class Paralline:
    """
--------
| Help |
--------

>>> import paralline
>>> help(paralline.Paralline)
>>> help(Paralline)

----------------
| What it does |
----------------

Reads a directory (or a set of files) and parse all the lines over multiple processes.
Processes receive the lines, run the same script overs those lines
and return their results as an iterable.
Paralline manages these processes and aggregates their results into an iterable
and returns it.


Files:
------
Paralline is designed to run multi Gigabytes long text files.
These files are supposed to have the same schema.
What we call a line is an amount of text data delimited by a separator.
These files can be any semi-structured files like:
    log files, json files, .csv, or xml files for instance.
Or any kind of text files that separates contents by the same separator (not need to be \n the default).


Script:
-------
1/ When run externally as a command

The option: -f (--script_file) is used.
e.g.: python3 paralline.py /where/is/my/text_file  -f /where/is/my/python_file.py

Each Process runs the same script.
This script is a Python file.
This Python file must support the following Function:
def digest(lines):
    <do something>

    return lines # or any iterable or None

This Function may return an iterable or None.
If all calls return None, Paralline would return an empty list.

2/ When run internally as an instance of the Paralline class,

The parameter: fct is used.
e.g.: paralline = Paralline()
      result_list = paralline.x(r'/where/is/my/text_file1', r'/where/is/my/text_file2', r'/or/a/directory', ..., fct=list(map(lambda lines:lines)))

"x" is an alias for the function "execute".
Here this lambda just returns lines
Script file could be a Python file like above.

But preferably it is a Python function.
It can be a lambda function or any Python (def) function.
This function must support one argument: lines.
> Because the function is serialized the Python Package: "dill" must be installed.


Processes:
----------
One can define the number of processes to run,
but by default Paralline would run as much processes as there are cores on the machine.


------------------
| How it does it |
------------------

No matter what the size of a file is,
Paralline splits the files in packet of lines of same size (shunk-size) as much as possible.
Each packet ends boundary, by a legitimate separator.

Note:
-----
a) The default separator is "\n" but it can be provided as a command option "-l" (or "--line_separator").
Or as a parameter: "line_separator" of the function "x" of the Paralline instance.
b) If Paralline cannot reach the end of the line with the range of "line_max_size" (default 1m),
it tries to go to the end of the file.
But it will raise a Warning:
    ParalleleEndLineNotFoundWarning:Contracts:ajustEnd: File: <file_name> => Unable to seek line separator from end: 1234 within line_max_size: 1M !
    You should considere to increase line_max_size.
This is explicite: either you wrong and you provided a bad "line_separator" that doesn't exist in the file,
or line_max_size is not big enought !

A packet may be built of many lines spreaded over one or multiple files.

Actually in Paralline a Packet is a definition that lives within a "contract".
A "contract" defines the disk offset of the first and the last line of the packet.
A "contract" also defines the files where the lines come from.
In a packet they are as many line that are need to reach shunk_size.

Contracts are equally (as much possible) distributed over processes.

- processes iterates over their set of contracts.
- processes read from the files as many lines need for the contract and operate the lines
into the regular funtion.
- The function returns an iterable or None.
- This iterable is streamed up to the Paralline manager which extends it up to the main list.
- The main list is returned by the "x" function.

> Because each process reads the same file system as they access randomly to the set of files,
they must share the same FS.
> This point is a landmark for the future version which plans to support remote worker.


Examples:
---------
Into the Paralline directory they are too couple of files:
- test1.txt and test.py
- test2.txt and test2.py
$> cd <paralline_dir>

a) To run them on command line:
python3 paralline.py test1.txt -f test1.py

b) To run them in Python interpreter:
$> python3
>>> from paralline import Paralline
>>> paralline = Paralline()
>>> paralline.x(test1.txt, fct=test1.py)
or
>>> paralline.x(test1.txt, fct=list(map(lambda lines:lines)))

e.g.: If you run this:
python3 paralline.py test1.txt  -f test1.py -d
You would see this:

Result Lines:
-------------
1 Lorem ipsum dolor sit amet, consectetur adipiscing elit,
2 sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
3 Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
4  aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit
5   esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
6    sunt in culpa qui officia deserunt mollit anim id est laborum
7     Lorem ipsum dolor sit amet, consectetur adipiscing elit,
8      sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
9 Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut1
10  aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit
11   esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
12    sunt in culpa qui officia deserunt mollit anim id est laborum
13     Lorem ipsum dolor sit amet, consectetur adipiscing elit,
14      sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
15 Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
16    aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit
17  esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
18 sunt in culpa qui officia deserunt mollit anim id est laborum

Lines Count: 19


Default:
--------
Default values are in the file named "paralline.attrs" into the paralline directory.


----------------
| How it works | You don't need to read this
----------------

1/ Launches the QDealer on Host Port.
The QDealer deals queues to the worker processes (that's it).
The Paralline manager and worker processes communicate via Multiprocessing queues.

2/ Redirects Outputs and logs to the Paralline manager.

3/ Tries to Launch as many Workers as required by the "parallele" parameter.

4/ Calculation and Adjustment
-----------------------------
a) Obtains the total files size:
Reads the size of all files from the set of files or
the provided directory (eventually with the provided prefixes/suffixes).
Sums up all these sizes and obtains : "total_files_size" the total amount of bytes for the whole files.

b) Obtains the total size for one unit of work:
Divides this "total_files_size" per "proc_parallele" and obtains "uow_total_size": the total amount of bytes per process.

c/ Adjusts shunk_size (Safe guard):
-----------------------------------
if uow_total_size is lesser than  shunk_size than uow_total_size/2 becomes shunk_size.
if uow_total_size is greater than shunk_size than shunk_size is kept.


5/ Run Payload on all Workers and Join.
Process receive as much contracts as need to fill up uow_total_size.
"contract" must not be bigger than "shunk_size".
"""
    def __init__(self, config_file = None, worker_config_file = None, do_remote = False, max_shunk = None, mgr_host = None, mgr_port = None, line_max_size = None, line_separator = None, verbose = None):
        selfMethod='init'
        from io import StringIO
        global SERVER_UID
        # Server_uid:
        if SERVER_UID==None:SERVER_UID = tools.genUid()
        self.__fake_server_uid = tools.getMd5(SERVER_UID)
        # Configs:
        self.__configs = preferences.getConfigs(self.__fake_server_uid, config_file=config_file)
        self.__config_file = config_file
        self.__do_remote = do_remote
        if do_remote:
            # todo: self.__worker_configs = preferences.getWorkerConfigs(worker_config_file=worker_config_file)
            self.__worker_config_file = worker_config_file
        eprefix = 'Parsing Paralline.init Options =>'

        if max_shunk==None:max_shunk=self.__configs['max_shunk']
        if line_max_size==None:line_max_size=self.__configs['line_max_size']
        if line_separator==None:line_separator=self.__configs['line_separator']
        ## ARRET ICI !!! if line_separator in preferences.KNOWN_SPERATORS: line_separator = preferences.KNOWN_SPERATORS[line_separator]
        line_separator = line_separator.encode('utf8').decode('unicode_escape')

        # Host/Port:
        if mgr_host!=None and not (isinstance(mgr_host, str) and len(mgr_host.strip())!=0): raise excpt.ParallineSystemError(eprefix + 'Option: mgr_host incorrect, an host cannot be a blank string: "" !', fromClass=self.__class__.__name__, fromMethod=selfMethod)
        if mgr_port!=None and not str(mgr_port).isdigit(): raise excpt.ParallineSystemError(eprefix + 'Option: mgr_port incorrect, a port must be an interger !', fromClass=self.__class__.__name__, fromMethod=selfMethod)
        # Separator:
        if not isinstance(line_separator, str) or len(line_separator) == 0:raise excpt.ParallineSystemError(eprefix +  'Option: line_separator incorrect, a separator cannot be a blank string: "" !', fromClass=self.__class__.__name__, fromMethod=selfMethod)

        # Max Memory:
        # -----------
        memories = {'max_shunk': max_shunk, 'line_max_size': line_max_size}
        for option in ('max_shunk', 'line_max_size'):
            if not isinstance(memories[option], str) or len(memories[option].strip()) == 0: raise excpt.ParallineSystemError(eprefix + 'Option: %s with value: %s incorrect, the memory format is %S !' % (option, str(memories[option]), MEMORY_SYNTAX), fromClass=self.__class__.__name__, fromMethod=selfMethod)

            value = memories[option].lower()

            if value.endswith('m'):mem_unity = 'm'
            elif value.endswith('g') :mem_unity = 'g'
            else:raise excpt.ParallineSystemError(eprefix +  'Option: %s incorrect value: %s ! Memory should be expressed in G (Giga) or M (Mega) octets ! The Syntax is: %s.' % (option, value, MEMORY_SYNTAX), fromClass=self.__class__.__name__, fromMethod=selfMethod)
            mem_value = value[:-1]
            if not mem_value.isdigit():raise excpt.ParallineSystemError(eprefix +  'Option: %s incorrect value: %s ! This part: %s should be an integer ! The Syntax is: %s.' % (option, value, mem_value, MEMORY_SYNTAX), fromClass=self.__class__.__name__, fromMethod=selfMethod)
            mem_value = int(mem_value)

            if mem_unity == 'm':mem_value *=1024*1024
            elif mem_unity == 'g':mem_value *=1024*1024*1024

            memories[option]=mem_value

        self.__configs['max_shunk'] = memories['max_shunk']
        if mgr_host!=None:self.__configs['manager_host'] = mgr_host
        if mgr_port!=None:self.__configs['manager_port'] = mgr_port
        self.__configs['line_max_size'] =  memories['line_max_size']
        self.__configs['line_separator'] = line_separator
        if verbose!=None:self.__configs['verbose'] = verbose
        else:verbose=self.__configs['verbose']

        # ----
        # Doc:
        # ----
        if verbose >=5:
            sb = StringIO()
            sb.write("Paralline.init Instance created with:\n")
            sb.write(len("Paralline.init Instance created with:\n")*'=' + '\n')
            sb.write( ".max_shunk: %sM (Max memory used per process)\n" % (int(int(self.__configs['max_shunk']/1024)/1024)) )
            # Host/Port:
            sb.write(".Manager Host: %s, manager Port: %s (QDealer will start with that))\n" % (self.__configs['manager_host'], self.__configs['manager_port']))
            # line_separator:
            sb.write( ".line_separator: %s (Line are splitted regarding this separator)\n" % tools.str_to_raw(self.__configs['line_separator'] ) )
            # line_max_size:
            sb.write(".line_max_size: %sM (An exception will be raised, if the end of a line cannot be found below this value)\n" % (int(int(self.__configs['line_max_size']/1024)/1024)))
            # verbose:
            sb.write(".temp_dir: %s\n" % self.__configs['temp_dir'])
            # verbose:
            sb.write(".verbose: %s\n" % self.__configs['verbose'])
            sb.write("-\n-\n")
            pprint (sb.getvalue())

    def getVerbose(self):
        return self.__configs['verbose']

    def x(self, *files, suffixes=None, prefixes=None, fct=None, parallele = None, O=None, o=None, split_log=False):
        return self.execute(*files, suffixes=suffixes, prefixes=prefixes, fct=fct, parallele=parallele, O=O, o=o, split_log=split_log)

    def execute(self, *files, suffixes=None, prefixes=None, fct=None, parallele = None, O=None, o=None, split_log=False):
        selfMethod="execute"
        import collections
        from os import listdir
        from io import StringIO
        global QDEALER
        eprefix = 'Parsing Paralline.execute Options =>'
        self.__files = files

        # suffixes:
        if suffixes!=None and len(suffixes)==0:raise excpt.ParallineSystemError(eprefix +  'Option: %s incorrect, suffixes cannot be a blank string: "" !' % ('suffixes'), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        # prefixes:
        if prefixes!=None and len(prefixes)==0:raise excpt.ParallineSystemError(eprefix +  'Option: %s incorrect, prefixes cannot be a blank string: "" !' % ('prefix'), fromClass=self.__class__.__name__, fromMethod=selfMethod)        # Prefix:
        if files==None or len(files)==0 or not isinstance(files, collections.Iterable):raise excpt.ParallineSystemError(eprefix +  'Option: %s incorrect, At least one file must provided. Many File(s) or directories can provided as arguments.' % ('files'), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        if fct==None or not (callable(fct) or isinstance(fct, str)):raise excpt.ParallineSystemError(eprefix +  'Option: %s incorrect, fct: must be either a function (a callable) or a python ".py" file path.' % ('fct'), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        if parallele == None:parallele = preferences.PROC_PARALLELE

        # Files:
        # ------
        # *files
        input_files = []
        for file in files:
            file=path.normpath(file)
            if not path.exists(file):raise excpt.ParallineSystemError(eprefix +  'File: %s should exist !' % file, fromClass=self.__class__.__name__, fromMethod=selfMethod)
            if path.isfile(file):input_files.append(file)
            elif path.isdir(file):
                ld = listdir(file)
                if (suffixes, prefixes) == (None, None):
                    x_files = [f for f in ld if path.isfile(path.join(file, f))]
                else:
                    x_files = []
                    if suffixes!=None:
                        _suffixes=suffixes.split(',')
                        for _suffix in _suffixes:
                            x_files.extend([f for f in ld if path.isfile(path.join(file, f)) and f.endswith(_suffix)])

                    if prefixes!=None:
                        if prefixes!=None and len(x_files)!=0:
                            ld = x_files
                            x_files = []

                        _prefixes=prefixes.split(',')
                        for _prefix in _prefixes:
                            x_files.extend([f for f in ld if path.isfile(path.join(file, f)) and f.startswith(_prefix)])

                input_files.extend([path.join(file, f) for f in x_files])

                for f in input_files:
                    if not path.isfile(f):raise excpt.ParallineSystemError(eprefix +  'File: %s should exist !', fromClass=self.__class__.__name__, fromMethod=selfMethod)

            else:raise excpt.ParallineSystemError(prefixes +  'File: %s should exist !' % file, fromClass=self.__class__.__name__, fromMethod=selfMethod)

        if not callable(fct):
            if not path.isfile(fct) or not fct.endswith('.py'):raise excpt.ParallineSystemError(eprefix +  'Option fct: %s should be either a Python Callable or an existing Python file !' % fct, fromClass=self.__class__.__name__, fromMethod=selfMethod)
            import sys
            fct = path.normpath(fct)
            bdir, mod = path.split(fct)
            mod_name = mod.split('.py')[0]

            if not fct in sys.path:sys.path.append(path.split(fct)[0])

            try:
                pprint ('Paralline.execute Loading Module: %s.' % mod)
                mod = __import__(mod_name, None, None, [mod_name])
            except ImportError as e:
                sb = StringIO()
                if self.__verbose>=5:
                    import sys, traceback
                    traceback.print_exc(file=sb)
                    pprint (sb.getvalue())

                raise ImportError(excpt.ParallineSystemError(eprefix +  'Option fct: Error in trying to load module: %s ! Please, Check if the file __init__.py exists into the directory: %s.' % (mod_name, bdir), fromClass=self.__class__.__name__, fromMethod=selfMethod))

            if not hasattr(mod, 'digest'):raise ImportError(excpt.ParallineSystemError(eprefix +  'Option fct: Module: %s should support a function named: "digest(lines)" !' % mod_name, fromClass=self.__class__.__name__, fromMethod=selfMethod))
            digest = getattr(mod, 'digest')
            if not callable(digest):raise ImportError(excpt.ParallineSystemError(eprefix +  'Option fct: Module: %s should support a function named: "digest(lines)" !' % mod_name, fromClass=self.__class__.__name__, fromMethod=selfMethod))
            self.__fct = digest

        else:self.__fct = fct

        self.__proc_parallele = parallele


        """
        ----------------------------------------
        | How it works (Excerpts from the doc) |
        ----------------------------------------


        1/ Launches QDealer on Host Port :
        ----------------------------------
        """

        if self.__configs['verbose'] == 0:self.__nostdout=True
        else:self.__nostdout=False
        if QDEALER==None:
            self.launchQDealer(nostdout=self.__nostdout)
            pprint('1. <-- Paralline.execute Launching QDealer')
            QDEALER = QueueManager(address=(self.__configs['manager_host'], self.__configs['manager_port']), authkey=SERVER_UID.encode('utf-8'))
            QDEALER.connect()
            pprint('1. --> Paralline.execute Launched QDealer')


        """
        2/ Launches Log Printer :
        --------------------------
        """

        self.__queue_response_log = QDEALER.get_temp_queue()
        try:self.__queue_response_log
        except:
            self.__queue_response_log=None
            raise excpt.ParallineSystemError('Unable to retreive queue_response_log !', fromClass=self.__class__.__name__, fromMethod=selfMethod)

        pprint('-\n-\n')
        pprint('2. <-- Paralline.execute Launching LogPrinter')
        log_printer = LogPrinter(queue_response_log = self.__queue_response_log, output_log = o, split_log = split_log, nostdout = self.__nostdout, temp_dir = self.__configs['temp_dir'])
        log_printer.start()

        pprint('2. --> Paralline.execute Launched LogPrinter', qlog = self.__queue_response_log)

        # Doc:
        # ----
        if self.getVerbose() >=5:
            # *files, suffixes=None, prefixes=None, fct=None, parallele = None, O=None, o=None
            # Doc:
            # ----
            sb = StringIO()
            sb.write("-\n-\n")
            msg = "Paralline.execute Running with the following options:\n"
            sb.write(msg)
            sb.write(len(msg)*'=' + '\n')
            sb.write("(Paralline.execute Will run function: %s on %s files, accross %s processes !)\n" % (self.__fct.__name__, len(input_files), parallele))
            # function:
            sb.write(".Function: %s\n" % self.__fct.__name__)
            # suffixes:
            if suffixes!=None:sb.write(".Suffixes: %s\n" % suffixes)
            # prefixes:
            if prefixes!=None:sb.write(".Prefixes: %s\n" % prefixes)
            # parallele:
            if parallele!=None:sb.write(".Parallele: %s\n" % parallele)
            # O:
            if O!=None:sb.write(".Output_file: %s\n" % O)
            # o:
            if o!=None:sb.write(".Output_log: %s\n" % o)
            # split_log:
            if split_log:sb.write(".Split_log: %s (Worker logs will be dumped into: %s) \n" % (split_log, log_printer.getDirWorker()))
            # Files:
            if self.getVerbose() >=10:
                sb.write(".Files ==>\n")
                for file in input_files:sb.write(3*" " + file + '\n')
            else:
                sb.write("Files: %s\n" % len(input_files))

            sb.write("-\n-\n")

            pprint(sb.getvalue(), qlog = self.__queue_response_log)


        """
        3/ Tries to Launch Workers :
        ----------------------------
        """

        pprint('3. <-- Paralline.execute Initiating WorkerManager', qlog = self.__queue_response_log)
        manager = Manager( QDEALER, server_uid = SERVER_UID, fct = self.__fct, mgr_host = self.__configs['manager_host'], mgr_port = self.__configs['manager_port'], proc_parallele = self.__proc_parallele, queue_response_log = self.__queue_response_log, line_separator = self.__configs['line_separator'], abort_when_fail_to_launch_one_worker=self.__configs['abort_when_fail_to_launch_one_worker'], worker_abort_when_fail_to_run_one_shunk=self.__configs['worker_abort_when_fail_to_run_one_shunk'], sctraces = self.__configs['sctraces'], temp_dir = self.__configs['temp_dir'], verbose = self.__configs['verbose'])
        self.__proc_parallele = manager.getRealWorkerCount()
        pprint('3. --> Paralline.execute Initiating WorkerManager', qlog = self.__queue_response_log)
        if self.__proc_parallele == 0:
            log_printer.terminate() # Quit log_printer
            return


        """
        4/ Calculation and Adjustment :
        --------------------------------
        a) Obtains the total_files_size
        - Reads the size of all files from the provided directory (eventually with the provided suffixes)
        - sums up all these sizes and obtains : total_files_size
        """

        pprint('-\n-\n', qlog = self.__queue_response_log)
        msg = "4. Paralline.execute Calculation results :"
        pprint(msg, qlog = self.__queue_response_log)
        pprint(len(msg)*'-', qlog = self.__queue_response_log)

        from os import listdir, stat

        total_files_size = 0
        stat_files = {}

        for file in input_files:
            fstat = stat(file)
            fsize = int(fstat.st_size)
            stat_files[file] = fsize

            total_files_size +=fsize

        pprint("a. .total_files_size: %s" % total_files_size, qlog = self.__queue_response_log)

        """
        b) Obtains the total share size for one unit of work:
        - divide this total_files_size per proc_parallele and obtains uow_total_size (the total share size for one unit of work)
        """
        uow_total_size = int(total_files_size/self.__proc_parallele)
        uow_total_size = int(uow_total_size)
        pprint("b. .uow_total_size: %s (The sum of all shunks for one process (divided by two).)" % uow_total_size, qlog = self.__queue_response_log)


        """
        c/ Defines shunk_size (Safe guard):
        -----------------------------------
        """
        # - if uow_total_size is lesser than  max_shunk, uow_total_size becomes shunk_size:
        if uow_total_size <= self.__configs['max_shunk']: shunk_size = int(uow_total_size/2)
        # - if uow_total_size is greater than max_shunk, max_shunk becomes shunk_size:
        else: shunk_size = self.__configs['max_shunk']

        pprint("c. .Definitive shunk_size: %s  (The size of one shunks for one process.)" % shunk_size, qlog = self.__queue_response_log)


        """
        5/ Contracts :
        --------------
        """

        pprint('-\n-\n', qlog = self.__queue_response_log)
        msg = "5. Paralline.execute Tailoring Contracts :"
        pprint(msg, qlog = self.__queue_response_log)
        pprint(len(msg)*'-', qlog = self.__queue_response_log)

        pprint ('<-- Entering Contract', qlog = self.__queue_response_log )
        contract = Contract(files=stat_files, shunk_size=shunk_size, uow_total_size = uow_total_size, line_max_size = self.__configs['line_max_size'], line_separator = self.__configs['line_separator'],   mac_parallele = 1, proc_parallele = self.__proc_parallele, output_log=self.__queue_response_log, verbose = self.getVerbose())
        proc_paralleles = contract.generates()
        pprint ('--> Leaving Contract', qlog = self.__queue_response_log )

        # This shunk_size is the maximum amount of memory used per process, at one time.
        # There will be as many process as need to consume all the total_file_size.

        """
        6/ Run Payload :
        ----------------
        """
        pprint('-\n-\n', qlog = self.__queue_response_log)
        msg = "6. Paralline.execute Injecting Payload :"
        pprint(msg, qlog = self.__queue_response_log)
        pprint(len(msg)*'-', qlog = self.__queue_response_log)

        manager.injectPayload(proc_paralleles)


        """
        7/ Launches OutPut Printer and Join :
        -------------------------------------
        """
        pprint('-\n-\n', qlog = self.__queue_response_log)
        msg = "7. <-- Paralline.execute Lauching OutPutPrinter and join"
        pprint(msg, qlog = self.__queue_response_log)
        msg = "7. --> Paralline.execute Lauching OutPutPrinter and join"
        pprint(msg, qlog = self.__queue_response_log)

        output_printer = OutputPrinter(queue_response_outputs = manager.getQResponseOutPuts(), output_file = O, line_separator = self.__configs['line_separator'])
        output_printer.start()
        output_printer.join() # Wait for output_printer (Workers Output)


        """
        8/ Terminates :
        -------------------------------------
        """
        pprint('-\n-\n', qlog = self.__queue_response_log)
        msg = "8. <-- Paralline.execute Terminating decently and join LogPrinter"
        pprint(msg, qlog = self.__queue_response_log)

        # log_printer.terminate() # Quit log_printer
        log_printer.shutdown() # Quit log_printer
        log_printer.terminate() # Quit log_printer

        self.__queue_response_log = None
        # Guive time to all Q consumers to end clean !
        import time
        time.sleep(1)

        msg = "8. --> Paralline.execute Terminating decently and join LogPrinter"
        pprint(msg, qlog = self.__queue_response_log)
        pprint("Paralline.execute ended !")

        # Only if output_file is None, lines would represente all the worker outputs:
        return output_printer.getLines()

    def launchQDealer(self, nostdout = False):
        from multiprocessing import Process
        import qdealer
        tools.isHostPortFree(self.__configs['manager_host'], self.__configs['manager_port'])

        # Protect server_uid into external temp file, soon destroyed. A001:
        file_server_uid=tools.FILE_SERVER_UID_PREFIX + tools.genUid()
        fd=open(path.normpath(self.__configs['temp_dir'] + '/' + file_server_uid + '.dat'), 'wb')
        fd.write(SERVER_UID.encode('utf-8'))
        fd.close()

        kwargs = {'host': self.__configs['manager_host'], 'port': self.__configs['manager_port'], 'server_uid': file_server_uid, 'nostdout': nostdout, 'temp_dir': self.__configs['temp_dir'], 'verbose': self.__configs['verbose']}
        self.__qdealer_process = Process(target=qdealer.main, args=[], kwargs = kwargs)
        self.__qdealer_process.daemon = True
        self.__qdealer_process.start()
        import time
        time.sleep(3)



"""
-------------
| CONTRACTS |
-------------
"""

class Contract:
    def __init__(self, files=None, shunk_size=None, uow_total_size=None, line_max_size=None, line_separator=None, mac_parallele=None, proc_parallele=None, output_log = None, verbose = 0):
        """
        mac_parallele: nb machine(s).
        """
        self.files = files
        self.shunk_size = shunk_size
        self.uow_total_size = uow_total_size
        self.line_max_size = line_max_size
        self.line_separator =  line_separator

        self.mac_parallele = mac_parallele # nb machine(s).
        self.proc_parallele = proc_parallele # nb proc(s).
        self.__output_log = output_log
        self.__verbose = verbose

    def getVerbose(self):
        return self.__verbose

    def generates(self):
        shunks = {}
        shunk_index = 0
        shunks[shunk_index] = []
        shunk_size=0 # shunk_size boundary

        proc_paralleles = {}

        for file in self.files:

            if self.getVerbose()>10:pprint("Paralline.Contract Scanning file: %s (%s)" % (file, self.files[file]), qlog = self.__output_log)

            fsize = self.files[file]
            fcum_size = 0

            while fcum_size < fsize:
                begin = fcum_size
                new_fcum_size  = fcum_size + self.shunk_size
                end = new_fcum_size
                if new_fcum_size > fsize:end = fsize
                else:end = self.ajustEnd(file = file, end = end)

                delta = end - begin
                fcum_size+=delta
                shunk_size+=delta

                # Rupture :
                # ---------
                if shunk_size>self.shunk_size and len(shunks[shunk_index])!=0:
                    shunk_size=delta
                    shunk_index+=1

                if shunk_index not in shunks:shunks[shunk_index] = []

                shunks[shunk_index].append({'file': file, 'begin': begin, 'end': end, 'shunk_index': shunk_index})

        # Distribute per machine/proc:
        # ----------------------------
        break_all = False
        shunk_index = 0
        while(shunk_index < len(shunks)):
            for mac_index in range(self.mac_parallele):
                for proc_index in range(self.proc_parallele):
                    if mac_index not in proc_paralleles:proc_paralleles[mac_index] = {}
                    if proc_index not in proc_paralleles[mac_index]: proc_paralleles[mac_index][proc_index] = {}

                    proc_paralleles[mac_index][proc_index][shunk_index] = shunks[shunk_index]
                    shunk_index+=1

                    if shunk_index >= len(shunks):
                        break_all=True
                        break

                if break_all:break
            if break_all: break

        if self.getVerbose()>20:
            for mac_index in range(len(proc_paralleles)):
                for proc_index in range(len(proc_paralleles[mac_index])):
                    for shunk_index in proc_paralleles[mac_index][proc_index]:
                        shunks = proc_paralleles[mac_index][proc_index][shunk_index]
                        for shks in shunks:
                            msg = ("- %s>Shunk for Machine: %s, Process: %s, Index: %s, startsAt: %s, endsAt: %s\n" % (shks['file'], mac_index, proc_index, shunk_index, shks['begin'], shks['end']))
                            pprint(msg, qlog = self.__output_log)

        return proc_paralleles

    def ajustEnd(self, file = None, end = None):
        fd = open(file, 'rb')
        fd.seek(end)
        s = fd.read(self.line_max_size).decode('utf-8')
        fd.close()

        index = s.find(self.line_separator)

        if index<0:
            warnings.warn('ParalleleEndLineNotFoundWarning:Contracts:ajustEnd: File:%s=> Unable to seek line separator from end: %s within line_max_size: %s ! You should considere to increase line_max_size.' % (file, end, self.line_max_size))
            return end

        else:return end + index



"""
-----------
| Manager |
-----------
"""

class Manager:

    def __init__(self, qdealer, server_uid = None, fct = None, mgr_host = None, mgr_port = None, proc_parallele = None, queue_response_log = None, abort_when_fail_to_launch_one_worker=False, worker_abort_when_fail_to_run_one_shunk=None, line_separator = None, sctraces=None, temp_dir=None, verbose=0):
        selfMethod='init'
        self.__sctraces = sctraces
        self.__temp_dir = temp_dir
        self.__qdealer = qdealer
        self.__verbose = verbose
        self.__queue_response_log = queue_response_log

        # Launch Workers:
        # ---------------
        self.__workers_pool = workers.WorkersPool(qdealer=self.__qdealer, server_uid = SERVER_UID, fct = fct, line_separator = line_separator, qd_host = mgr_host, qd_port = mgr_port, proc_parallele = proc_parallele, queue_response_log = self.__queue_response_log, abort_when_fail_to_launch_one_worker=abort_when_fail_to_launch_one_worker, worker_abort_when_fail_to_run_one_shunk=worker_abort_when_fail_to_run_one_shunk, sctraces=self.__sctraces, temp_dir=self.__temp_dir, verbose=self.__verbose)

    def getRealWorkerCount(self):
        return self.__workers_pool.getRealWorkerCount()

    def getQResponseOutPuts (self):
        return self.__workers_pool.getQResponseOutPuts()

    def injectPayload(self, proc_paralleles):
        selfMethod='injectPayload'
        import json
        import time

        pool = self.__workers_pool.getPool()
        pool_keys = list(pool.keys())

        pprint ('<-- injectPayload [Entering]', qlog = self.__queue_response_log )
        pprint ("InjectPayload Machine: 0 (This version only supports one machine for now !)", qlog = self.__queue_response_log )

        to_dels = []

        for proc_index in pool_keys:
            w = pool[proc_index]

            if proc_index in proc_paralleles[0]:
                pprint ('<-(%s)' % proc_index + 3*" " + 'Worker (Process): %s Injecting.' % proc_index, qlog = self.__queue_response_log )

                shunks = proc_paralleles[0][proc_index]
                shunks_keys = list(shunks.keys())
                shunks_keys.sort()

                for shunk_index in shunks_keys:
                    pprint ('<(%s)'% shunk_index + 6*" " + 'Shunk index: %s Injecting.' % shunk_index, qlog = self.__queue_response_log )
                    parts = proc_paralleles[0][proc_index][shunk_index]
                    if len(parts) == 0:continue

                    payload = json.dumps(parts)
                    w.getQRequestNewTask().put(payload, True)
                    pprint ('(%s)>' % shunk_index + 6*" " + 'Shunk index: %s Injected.' % shunk_index, qlog = self.__queue_response_log )

                time.sleep(TIME_REQUIRED_BY_LAYER_NOT_TO_MISS_PACKET) # Required for the Q not to miss packet !
                w.getQRequestNewTask().put(0, True)

                pprint ('(%s)->' % proc_index + 3*" " + 'Worker (Process): %s Injected !' % proc_index, qlog = self.__queue_response_log )
                pprint ('-', qlog = self.__queue_response_log )

            else:to_dels.append(proc_index)

        for pool_index in to_dels:pool[pool_index].suicide()
        pprint ('--> InjectPayload [Leaving]', qlog = self.__queue_response_log )

    def getVerbose(self):
        return self.__verbose



class OutputPrinter(threading.Thread):
    def __init__(self, queue_response_outputs = None, output_file = None, line_separator=None):
        from os import path
        threading.Thread.__init__(self, None, None, 'OutputPrinter')
        self.daemon = True
        self.__queue_response_outputs = queue_response_outputs
        if output_file!=None:
            self.__lines = None
            self.__output_file = path.normpath(output_file)
            self.__fd_output_file = open(self.__output_file, 'rb')
        else:
            self.__output_file = None
            self.__fd_output_file = None
            from scalike import sclist
            self.__lines = sclist()
        self.__isAlive = True
        self.__line_separator = line_separator
        self.responses = []

    def run(self):
        # Loop optimization:
        queue_response_outputs = self.__queue_response_outputs
        output_file = self.__output_file
        fd_output_file =self.__fd_output_file
        lines = self.__lines

        while self.__isAlive and len(queue_response_outputs)>0:

            for q_index in range(len(queue_response_outputs)):
                q = queue_response_outputs[q_index]
                data = None


                while self.__isAlive:
                    try:data = q.get(True, 1)
                    except Empty:break

                    if data in  (0, 1):
                        print ("[Worker: %s/%s, Finished with Status: %s]" % (q.worker_name, len(queue_response_outputs), data))
                        self.responses.append(data)
                        del queue_response_outputs[q_index]
                        break

                    if not isinstance(data, list):data = [data]
                    if output_file!=None:fd_output_file.write( self.__line_separator.join(data) )
                    else:lines.extend(data)

                if data in (0, 1):break

    def isAlive(self):
        return self.__isAlive

    def shutdown(self):
        try:self.__fd_output_file.close()
        except:pass
        self.__isAlive=False

    def getLines(self):
        return self.__lines

    def clearLines(self):
        self.__lines = None



import multiprocessing
class LogPrinter(multiprocessing.Process):
    def __init__(self, queue_response_log = None, output_log = None, split_log=False, nostdout = False, temp_dir=None):
        self.__isAlive = True
        from os import path
        multiprocessing.Process.__init__(self, None, None, 'logPrinter')
        self.daemon = True
        self.__temp_dir = temp_dir
        self.__queue_response_log = queue_response_log
        if output_log!=None:output_log = path.normpath(output_log)
        self.__output_log = output_log
        if self.__output_log!=None:self.__fd_output_log = open(path.normpath(self.__output_log), 'w')
        self.__nostdout = nostdout
        if output_log !=None:msg = output_log
        else:msg='stdout'
        pprint('LogPrinter.init will write logs to: %s' % msg )
        self.__split_log = split_log
        self.__dir_worker = None
        self.__prefix_worker = ''
        if self.__split_log:
            if self.__output_log == None:self.__dir_worker = self.__temp_dir
            else:
                self.__dir_worker, self.__prefix_worker = path.split(self.__output_log)
                self.__prefix_worker = path.splitext(self.__prefix_worker)[0] + '_'
        self.__fd_workers = {}

    def run(self):
        pprint('LogPrinter.run : Ready, waiting for inputs !')

        while self.__isAlive:
            try:
                data = str( self.__queue_response_log.get(True, 3) )
                self.write(data)

            except Empty:continue

    def write(self, data):
        if data.startswith(tools.RedirectStd.PREFIX_SEPARATOR_BEGIN):
            spl = data.split(tools.RedirectStd.PREFIX_SEPARATOR_BEGIN)
            data = tools.RedirectStd.PREFIX_SEPARATOR_BEGIN.join(spl[1:])
            spl = data.split(tools.RedirectStd.PREFIX_SEPARATOR_END)
            worker = spl[0]
            data = tools.RedirectStd.PREFIX_SEPARATOR_END.join(spl[1:])

            if self.__split_log:
                if worker not in self.__fd_workers:self.__fd_workers[worker] = open(path.normpath(self.__dir_worker + '/' + self.__prefix_worker + worker + '.log'), 'w')
                self.__fd_workers[worker].write(data)
                self.__fd_workers[worker].flush()
                return

        self.__write(data)

    def __write(self, data):
        import sys
        if self.__nostdout:return
        if self.__output_log:self.__fd_output_log.write(data.encode('utf-8')) # Print File
        else:sys.stdout.write(data) # Print Console

    def getDirWorker(self):
        return self.__dir_worker

    def shutdown(self):
        self.__isAlive = False
        for fd in self.__fd_workers.values():
            fd.flush()
            fd.close()
        i = 0

        # Free the Q:
        while True:
            i+=1
            try:
                data = str( self.__queue_response_log.get(True, 2) )
                self.write(data)
            except Empty:break
            except:break



# -----------------------------------------------------* MAIN *--------------------------------------------------------#



def usage():
    return """
--------
| Help |
--------

>>> import paralline
>>> help(paralline.Paralline)
>>> help(Paralline)

----------------
| What it does |
----------------

Reads a directory (or a set of files) and parse all the lines over multiple processes.
Processes receive the lines, run the same script overs those lines
and return their results as an iterable.
Paralline manages these processes and aggregates their results into an iterable
and returns it.


Files:
------
Paralline is designed to run multi Gigabytes long text files.
These files are supposed to have the same schema.
What we call a line is an amount of text data delimited by a separator.
These files can be any semi-structured files like:
    log files, json files, .csv, or xml files for instance.
Or any kind of text files that separates contents by the same separator (not need to be \n the default).


Script:
-------
1/ When run externally as a command

The option: -f (--script_file) is used.
e.g.: python3 paralline.py /where/is/my/text_file  -f /where/is/my/python_file.py

Each Process runs the same script.
This script is a Python file.
This Python file must support the following Function:
def digest(lines):
    <do something>

    return lines # or any iterable or None

This Function may return an iterable or None.
If all calls return None, Paralline would return an empty list.

2/ When run internally as an instance of the Paralline class,

The parameter: fct is used.
e.g.: paralline = Paralline()
      result_list = paralline.x(r'/where/is/my/text_file1', r'/where/is/my/text_file2', r'/or/a/directory', ..., fct=list(map(lambda lines:lines)))

"x" is an alias for the function "execute".
Here this lambda just returns lines
Script file could be a Python file like above.

But preferably it is a Python function.
It can be a lambda function or any Python (def) function.
This function must support one argument: lines.
> Because the function is serialized the Python Package: "dill" must be installed.


Processes:
----------
One can define the number of processes to run,
but by default Paralline would run as much processes as there are cores on the machine.


------------------
| How it does it |
------------------

No matter what the size of a file is,
Paralline splits the files in packet of lines of same size (shunk-size) as much as possible.
Each packet ends boundary, by a legitimate separator.

Note:
-----
a) The default separator is "\n" but it can be provided as a command option "-l" (or "--line_separator").
Or as a parameter: "line_separator" of the function "x" of the Paralline instance.
b) If Paralline cannot reach the end of the line with the range of "line_max_size" (default 1m),
it tries to go to the end of the file.
But it will raise a Warning:
    ParalleleEndLineNotFoundWarning:Contracts:ajustEnd: File: <file_name> => Unable to seek line separator from end: 1234 within line_max_size: 1M !
    You should considere to increase line_max_size.
This is explicite: either you wrong and you provided a bad "line_separator" that doesn't exist in the file,
or line_max_size is not big enought !

A packet may be built of many lines spreaded over one or multiple files.

Actually in Paralline a Packet is a definition that lives within a "contract".
A "contract" defines the disk offset of the first and the last line of the packet.
A "contract" also defines the files where the lines come from.
In a packet they are as many line that are need to reach shunk_size.

Contracts are equally (as much possible) distributed over processes.

- processes iterates over their set of contracts.
- processes read from the files as many lines need for the contract and operate the lines
into the regular funtion.
- The function returns an iterable or None.
- This iterable is streamed up to the Paralline manager which extends it up to the main list.
- The main list is returned by the "x" function.

> Because each process reads the same file system as they access randomly to the set of files,
they must share the same FS.
> This point is a landmark for the future version which plans to support remote worker.


Examples:
---------
Into the Paralline directory they are too couple of files:
- test1.txt and test.py
- test2.txt and test2.py
$> cd <paralline_dir>

a) To run them on command line:
python3 paralline.py test1.txt -f test1.py

b) To run them in Python interpreter:
$> python3
>>> from paralline import Paralline
>>> paralline = Paralline()
>>> paralline.x('test1.txt', fct='test1.py')
or
>>> paralline.x('test1.txt', fct=list(map(lambda lines:lines)))

e.g.: If you run this:
python3 paralline.py test1.txt  -f test1.py -d
You would see something like that:

Result Lines:
-------------
1 Lorem ipsum dolor sit amet, consectetur adipiscing elit,
2 sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
3 Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
4  aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit
5   esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
11   esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
12    sunt in culpa qui officia deserunt mollit anim id est laborum
13     Lorem ipsum dolor sit amet, consectetur adipiscing elit,
14      sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
15 Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut
6    sunt in culpa qui officia deserunt mollit anim id est laborum
7     Lorem ipsum dolor sit amet, consectetur adipiscing elit,
8      sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
9 Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut1
10  aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit
16    aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit
17  esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
18 sunt in culpa qui officia deserunt mollit anim id est laborum

Lines Count: 19

Please note:
It is not supposed to keep the lines order, because processes run concurently on shunks.


Default:
--------
Default values are in the file named "paralline.attrs" into the paralline directory.


----------------
| How it works | You don't need to read this
----------------

1/ Launches the QDealer on Host Port.
The QDealer deals queues to the worker processes (that's it).
The Paralline manager and worker processes communicate via Multiprocessing queues.

2/ Redirects Outputs and logs to the Paralline manager.

3/ Tries to Launch as many Workers as required by the "parallele" parameter.

4/ Calculation and Adjustment
-----------------------------
a) Obtains the total files size:
Reads the size of all files from the set of files or
the provided directory (eventually with the provided prefixes/suffixes).
Sums up all these sizes and obtains : "total_files_size" the total amount of bytes for the whole files.

b) Obtains the total size for one unit of work:
Divides this "total_files_size" per "proc_parallele" and obtains "uow_total_size": the total amount of bytes per process.

c/ Adjusts shunk_size (Safe guard):
-----------------------------------
if uow_total_size is lesser than  shunk_size than uow_total_size/2 becomes shunk_size.
if uow_total_size is greater than shunk_size than shunk_size is kept.


5/ Run Payload on all Workers and Join.
Process receive as much contracts as need to fill up uow_total_size.
"contract" must not be bigger than "shunk_size".
"""


def main():
    selfMethod='main'
    import optparse
    global VERBOSE
    from io import StringIO

    try:

        # Options:
        # --------
        parser = optparse.OptionParser(usage())
        parser.add_option("-f", "--script_file", dest='script_file', help="Script to be run. This script will be imported as a python module by all processes.\
                This script must support a \"def digest(lines)\" function.\This function may return an iterable or None.")
        parser.add_option("-z", "--suffixes", dest="suffixes", help="Optional. You may provide a comma separated list of suffixes for the files read from the directory.")
        parser.add_option("-a", "--prefixes", dest="prefixes", help="Optional. You may provide a comma separated list of prefixes for the files read from the directory.")
        parser.add_option("-p", "--proc_parallele", type=int, dest="proc_parallele", default=preferences.PROC_PARALLELE, help="[default: %default] Optional. Number of processes (or Workers) to run, Default: number of processor on this machine")
        parser.add_option("-O", "--output_file", dest="output_file", help="Optional. The output_file that will concentrate all workers output.\
If No output_file is provided beware that all the output is stored as a list in memory.")
        parser.add_option("-o", "--output_log", dest="output_log", help="Optional. The output_log that will concentrate all workers logs.")
        parser.add_option("-s", "--split_log", action="store_true", dest="split_log", help="Optional. If split_log is set the output logs for workers are splitted into separated log files (endind with suffix: w#.log). They go to the temp_dir: see paralline.attrs.")
        # Advanced:
        og = optparse.OptionGroup(parser, 'Advanced', description='This group of options shows advanced usages.')
        parser.add_option_group(og)
        og.add_option("-g", "--confile", dest="confile", default=preferences.CONFIGURATION_FILE, help="[default: %default] Optional. Alternative Configuration file.")
        og.add_option("-S", "--max_shunk", dest="max_shunk", default=preferences.MAX_SHUNK, help="[default: %default] Optional. Max Memory used by one process.")
        og.add_option("--host", dest="mgr_host", default=preferences.MANAGER_HOST, help="[default: %default] Optional. Work Manager Host")
        og.add_option("--port", dest="mgr_port", type=int, default=preferences.MANAGER_PORT, help="[default: %default] Optional. Work Manager Port")
        og.add_option("-L", "--line_max_size", dest="line_max_size", default=preferences.LINE_MAX_SIZE, help="[default: %default] Optional." + HELP_LINE_MAX_SIZE)
        og.add_option("-l", "--line_separator", dest="line_separator", default=preferences.LINE_SEPARATOR, help="[default: %s] Optional. All file are read and split over this separator." % tools.str_to_raw(preferences.LINE_SEPARATOR))
        og.add_option("-d", "--dump", action="store_true", dest="dump", help="Optional. If provided will show resulted lines (dont use on huge output) as text, joining all lines together with the separator.")
        og.add_option("-v", "--verbose", dest="verbose", type=int, default=0, help="[default: %default] Optional. (int>=0) verbose level.")
        # Remote Options:
        og = optparse.OptionGroup(parser, 'Remote Future Options', description='(Future) This group of options is dedicated to Remote usages (For Workers nodes on remotes machine)./Future Not Availbale for now ! ')
        parser.add_option_group(og)
        og.add_option("-r", "--remote", action="store_true", dest="remote", default=False, help="(Future) [default: %default] Optional. The output_log that will concentrate all workers logs.\
If remote is provided the file node.attrs is read. And workers are run on remotes machines.")
        og.add_option("-G", "--worker_confile", dest="worker_confile", default=preferences.WORKER_CONFIGURATION_FILE, help="(Future) [default: %default] Optional. Alternative Worker Configuration file.")

        (options, args) = parser.parse_args()
        VERBOSE=options.verbose


        # Configure :
        # -----------
        sb=StringIO()
        sb.write("""Python command:
{u}
from paralline import Paralline
paralline = Paralline(config_file = r'{config_file}', worker_config_file = r'{worker_config_file}', do_remote = {do_remote}, max_shunk = '{max_shunk}', mgr_host= '{mgr_host}', mgr_port = {mgr_port}, line_max_size = '{line_max_size}', line_separator = r'{line_separator}', verbose = {verbose})\n""".format(
            u = len('Python command:')*'-', config_file = options.confile, worker_config_file = options.worker_confile, do_remote = options.remote, max_shunk = options.max_shunk, mgr_host= options.mgr_host, mgr_port = options.mgr_port,
            line_max_size = options.line_max_size, line_separator = tools.str_to_raw(options.line_separator), verbose = options.verbose))

        paralline = Paralline(config_file = options.confile, worker_config_file = options.worker_confile, do_remote = options.remote, max_shunk = options.max_shunk, mgr_host= options.mgr_host, mgr_port = options.mgr_port,
            line_max_size = options.line_max_size, line_separator = options.line_separator, verbose = options.verbose)


        # Execute :
        # ---------
        sb.write("""l = paralline.x({args}, suffixes=r'{suffixes}', prefixes=r'{prefixes}', fct=r'{fct}', parallele = {parallele}, O='{O}', o='{o}', split_log = {split_log} )""".format(
            args = ','.join(["r'" + arg + "'" for arg in args]), suffixes=options.suffixes, prefixes=options.prefixes, fct=options.script_file, parallele = options.proc_parallele, O=options.output_file, o=options.output_log, split_log = options.split_log))
        pprint (sb.getvalue().replace("r''", 'None').replace("r'None'", 'None').replace("'None'", 'None'))
        pprint ('-')

        l = paralline.x(*args, suffixes=options.suffixes, prefixes=options.prefixes, fct=options.script_file, parallele = options.proc_parallele, O=options.output_file, o=options.output_log, split_log = options.split_log )

        if options.dump:
            s = options.line_separator.join(l)
            print ("Result Lines:")
            print ('-'*len("Result Lines:"))
            print (s)
            print ("Lines Count:", len(s.split('\n')))


    except Exception as e:
        if options.verbose>=10:raise
        import sys
        sys.stderr.write('Exception %s => %s\n' % (e.__class__.__name__, str(e)))
        sys.exit(2)

if __name__ == "__main__":
        main()
