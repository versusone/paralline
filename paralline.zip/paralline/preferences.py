## This file is part of the Software: paralline.
## This file and paralline are provided under the MIT licence:
## The MIT Licence can be found at: https://tldrlegal.com/license/mit-license#fulltext
## and in the file LICENCE.txt of the current directory of the software.
##
## Copyright (c) 2007-2008, Patrick Germain Placidoux
## All rights reserved.
##
## Permission is hereby granted, free of charge, to any person obtaining a copy
## of this software and associated documentation files (the "Software"), to deal
## in the Software without restriction, including without limitation the rights
## to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
## copies of the Software, and to permit persons to whom the Software is
## furnished to do so, subject to the following conditions:
##
## The above copyright notice and this permission notice shall be included in all
## copies or substantial portions of the Software.
##
## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
## IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
## FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
## AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
## LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
## OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
## SOFTWARE.
##
##  @author: Patrick Germain Placidoux
##  @contact: paralline@gmx.com


# Launches preference.attrs:
# Manager is listening to Workers on Hostname

import tools
import excpt
from os import path
import multiprocessing

# Statics infos:
CONFIGURATION_FILE = path.normpath(tools.getInstallDir() + '/paralline.attrs')
WORKER_CONFIGURATION_FILE = path.normpath(tools.getInstallDir() + '/nodes.attrs')

SUPPORTED_ATTRS = {
# TEMP_DIR
'TEMP_DIR' : str,
# Parallele processors:
'PROC_PARALLELE' : int,
# Max proc Memory:
'MAX_SHUNK' : str,
#Manager Host/Port:
'MANAGER_HOST' : str,
'MANAGER_PORT' : int,
# Line:
'LINE_MAX_SIZE' : str,
'LINE_SEPARATOR' : str,
'VERBOSE' : int,
# Advanced:
'ABORT_WHEN_FAIL_TO_LAUNCH_ONE_WORKER' : bool,
'WORKER_ABORT_WHEN_FAIL_TO_RUN_ONE_SHUNK' : bool,
'APBLOCK_TIMOUT' : int,
'APBLOCK_SLICE' : int,
'TRC_TIME_IT': bool,
'TRC_TRACE_BACK_IF_GREATER_THAN': int,
'TRC_DUMP_FIRST_N_OCCURENCES': int,
'TRC_DUMP_LAST_N_OCCURENCES': int,
'TRC_DUMP_ALL_OCCURENCES': bool
}
TEMP_DIR = tools.getTempDir()
# Parallele processors:
PROC_PARALLELE = multiprocessing.cpu_count()

# Max proc Memory:
MAX_SHUNK = '30M'
#Manager Host/Port:
MANAGER_HOST = '127.0.0.1'
MANAGER_PORT = 8888
# Line:
LINE_MAX_SIZE = '1M'
LINE_SEPARATOR = '\n'
KNOWN_SPERATORS={
    r'\n': '\n',
    r'\r': '\r',
    r'\r\n': '\r\n',
    r'\t': '\t'
}
VERBOSE = 5

# Advanced:
ABORT_WHEN_FAIL_TO_LAUNCH_ONE_WORKER=False
WORKER_ABORT_WHEN_FAIL_TO_RUN_ONE_SHUNK=True
APBLOCK_TIMOUT = 10
APBLOCK_SLICE = 3

TRC_TIME_IT = False
TRC_TRACE_BACK_IF_GREATER_THAN = 20
TRC_DUMP_FIRST_N_OCCURENCES = 20
TRC_DUMP_LAST_N_OCCURENCES = 20
TRC_DUMP_ALL_OCCURENCES = False

QUEUE_MAX_SIZE = 1000000

def getConfigs(fake_server_uid, config_file=None):
    selfMethod = 'getConfigs'
    configs = {'sctraces' : {}}

    for attr in SUPPORTED_ATTRS:
        if not attr.lower().startswith('trc'):configs[attr.lower()] = globals()[attr]
        else:configs['sctraces'][attr.lower()] = globals()[attr]

    if config_file == None:config_file = CONFIGURATION_FILE
    config_file = path.normpath(config_file)
    prefix = 'Paralline Config file at: %s =>' % config_file
    if not path.isfile(config_file):raise excpt.ParallineSystemError(prefix +  'File Not found !', fromClass='Main', fromMethod=selfMethod)

    fd = open(config_file)
    lines = fd.readlines()
    fd.close()

    for line in lines:
        if line.startswith('#') or line.isspace():continue
        spl = line.split('=')
        if len(spl)!=2:raise excpt.ParallineSystemError(prefix +  'Unsupported Line: %s !' % line, fromClass='Main', fromMethod=selfMethod)

        attr, value = spl
        attr = attr.strip()

        if not attr.upper() in SUPPORTED_ATTRS:raise excpt.ParallineSystemError(prefix +  'Unsupported Attribute: %s ! Supported Attributes are: %s.' % (attr, ','.join([a.lower() for a in  SUPPORTED_ATTRS])), fromClass='Main', fromMethod=selfMethod)

        if attr.lower()!='line_separator':
            value = value.strip()
            if SUPPORTED_ATTRS[attr.upper()]==int:
                try:value=int(value)
                except:raise excpt.ParallineSystemError(prefix +  'Unsupported Attribute: %s ! Should be an integer !' % attr, fromClass='Main', fromMethod=selfMethod)
            elif SUPPORTED_ATTRS[attr.upper()]==bool:
                if value in ('False', 'false'):value=False
                elif value in ('True', 'true'):value=True
                else:raise excpt.ParallineSystemError(prefix +  'Unsupported Attribute: %s ! Should be a Boolean (true or false) !' % attr, fromClass='Main', fromMethod=selfMethod)

        if not attr.lower().startswith('trc'):
            if value not in (0, ''):configs[attr.lower()]=value
        else:configs['sctraces'][attr.lower()]=value

    configs['sctraces']['trc_output_dir'] = configs['temp_dir']

    return configs

def genOutputFiles(fake_server_uid):
    return path.normpath( TEMP_DIR + '/paralline_' + fake_server_uid + '.log')
