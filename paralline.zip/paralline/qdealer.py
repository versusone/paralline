## This file is part of the Software: paralline.
## This file and paralline are provided under the MIT licence:
## The MIT Licence can be found at: https://tldrlegal.com/license/mit-license#fulltext
## and in the file LICENCE.txt of the current directory of the software.
##
## Copyright (c) 2007-2008, Patrick Germain Placidoux
## All rights reserved.
##
## Permission is hereby granted, free of charge, to any person obtaining a copy
## of this software and associated documentation files (the "Software"), to deal
## in the Software without restriction, including without limitation the rights
## to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
## copies of the Software, and to permit persons to whom the Software is
## furnished to do so, subject to the following conditions:
##
## The above copyright notice and this permission notice shall be included in all
## copies or substantial portions of the Software.
##
## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
## IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
## FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
## AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
## LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
## OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
## SOFTWARE.
##
##  @author: Patrick Germain Placidoux
##  @contact: paralline@gmx.com


FAKE_SERVER_UID = None
OG_STDOUT = None

PERM_REGISTRED_QUEUES={}
PERM_REGISTRED_QUEUES_LOCK=None
TEMP_REGISTRED_QUEUES={}
TEMP_REGISTRED_QUEUES_LOCK=None
TEMP_QUEUE_TIMEOUT=300
##TEMP_REGISTRED_QUEUES_LOCK=threading.Lock() # test only
QMANAGER_THREAD=None
VERBOSE=None

from tools import ParallineLock
from os import path
import preferences
import tools
import excpt

from multiprocessing.managers import BaseManager
from multiprocessing import Queue
import threading
import time


#----------------#
# QManagerThread #
#----------------#


class QManagerThread(threading.Thread):
    SLEEP_SLICE=10

    def __init__(self):
        threading.Thread.__init__(self)  
        self.setName('QManagerThread')
        self.__isAlive=True
        self.__isRunning=False
        self.pause_event=threading.Event()
        self.pause_event.clear()
        
    def run(self):
        """
        Watch Dog for Qdealer
        """
        selfMethod='run'

        ## New Task
        while True and self.isAlive():

            if VERBOSE > 20:tools.pprint('QDealer:QManagerThread: Awakened for cleaning !')
            ts=time.time()

            # Cure Qeues:
            # -----------
            todels=[]
            for qid in TEMP_REGISTRED_QUEUES:
                queue, t=TEMP_REGISTRED_QUEUES[qid]
                if ts - t >= TEMP_QUEUE_TIMEOUT:todels.append(qid)
                
            for qid in todels:
                TEMP_REGISTRED_QUEUES_LOCK.acquire('run')
                if VERBOSE > 20:tools.pprint('QDealer:QManagerThread: Destroying Queue:' + str(qid) + ' !')
                del TEMP_REGISTRED_QUEUES[qid]
                TEMP_REGISTRED_QUEUES_LOCK.release()

            self.pause_event.wait(QManagerThread.SLEEP_SLICE)
    
    def isAlive(self):       
        return self.__isAlive    
    
    def shutdown(self):
        self.__isAlive=False


#---------#
# QMQueue #
#---------#


class QMQueue:

    def __init__(self, *args, **keywords):
        self.__queue = Queue(*args, **keywords)
    
    def _qmq_setId(self, id):
        self.__id=id
            
    def qmq_getId(self):
        return self.__id
    
    def qmq_print(self):
        return 'QMQeue: Says hello !'

    def put(self, *args, **keywords):
        return self.__queue.put(*args, **keywords)

    def get(self, *args, **keywords):
        return self.__queue.get(*args, **keywords)

    
#----------#
# MManager #
#----------#

class MManager(BaseManager):pass
class QManager:pass

def getPermQueue(id=None, client_pid=None):
    if id!=None:
        if id in PERM_REGISTRED_QUEUES:return PERM_REGISTRED_QUEUES[id][0]
        else:
            if client_pid!=None:more=' for client PID: ' + str(client_pid) + ' !'
            else:more=' !'
            raise excpt.ParallineSystemError('No Queue:' + str(id) + ' available' + more, fromClass='Main', fromMethod="getPermQueue")
    
    q=QMQueue(preferences.QUEUE_MAX_SIZE)
    q._qmq_setId(genQueueId())
    qid=q.qmq_getId()
    t=time.time()
    PERM_REGISTRED_QUEUES_LOCK.acquire('getPermQeue')       
    PERM_REGISTRED_QUEUES[qid]=(q, t)
    PERM_REGISTRED_QUEUES_LOCK.release()
    
    return q

def delPermQueue(id):
    if id not in PERM_REGISTRED_QUEUES:return

    PERM_REGISTRED_QUEUES_LOCK.acquire('getPermQeue')       
    del PERM_REGISTRED_QUEUES[id]
    PERM_REGISTRED_QUEUES_LOCK.release()

def getTempQueue(id=None, client_pid=None):

    if id!=None:
        if id in TEMP_REGISTRED_QUEUES:return TEMP_REGISTRED_QUEUES[id][0]
        else:
            if client_pid!=None:more=' for client PID: ' + str(client_pid) + ' !'
            else:more=' !'
            raise excpt.ParallineSystemError('No Queue:' + str(id) + ' available' + more, fromClass='Main', fromMethod="getTempQueue")

    q=QMQueue(preferences.QUEUE_MAX_SIZE)
    q._qmq_setId(genQueueId())
    qid=q.qmq_getId()
    t=time.time()
    TEMP_REGISTRED_QUEUES_LOCK.acquire('getTempQeue')       
    TEMP_REGISTRED_QUEUES[qid]=(q, t)
    TEMP_REGISTRED_QUEUES_LOCK.release()

    return q

def genQueueId():
    import random

    id=random.randint(1, 100000)
    id="%05i" % id

    return 'QMQ_' + str(int(time.time())) + '_' +  str(id)

def ping():
    return True



#################
##    Main     ##
#################

def main(host=None, port=None, server_uid=None, nostdout=False, temp_dir=None, verbose=0):
    global FAKE_SERVER_UID
    global QMANAGER_THREAD
    from os import remove
    global VERBOSE

    preferences.TEMP_DIR = tools.TEMP_DIR = temp_dir
    VERBOSE = verbose

    # -- server_uid:
    file_server_uid = path.normpath(preferences.TEMP_DIR + '/' + server_uid + '.dat')
    fd = open(file_server_uid, 'rb')
    server_uid = fd.read().decode('utf-8')
    fd.close()
    remove(file_server_uid)
    FAKE_SERVER_UID = tools.getMd5(server_uid)
    tools.init(server_uid)

    # Queues
    globals()['TEMP_REGISTRED_QUEUES_LOCK']=ParallineLock()
    globals()['PERM_REGISTRED_QUEUES_LOCK']=ParallineLock()
    globals()['NATIVE_SERVER_QUEUE_LOCK']=ParallineLock()

                                                #------------#


    ## Trailing parameters ckecks
    if not isinstance(port, int)  or port=='':raise excpt.ParallineParameterTypeError('port', 'int', str(port), fromClass='Main', fromMethod="main")
    if not isinstance(port, int):raise excpt.ParallineParameterTypeError('port', 'int', str(port), fromClass='Main', fromMethod="main")
   
    
    ## Redirect Output
    # from tools import RedirectStd
    # import sys
    # if VERBOSE<10:rstd=RedirectStd(log_file=path.normpath(preferences.TEMP_DIR + '/qdealer_' + FAKE_SERVER_UID +  '_output.log'), stdout=sys.stdout, stderr=sys.stderr)
    
    tools.pprint('\n\nQDealer: is trying to open host: %s, port: %s.' % (host, str(port)), '...')

    ## Start Q Cleaner
    QMANAGER_THREAD=QManagerThread()
    QMANAGER_THREAD.start()

    ## Start Q Dealer
    MManager.register('ping', callable=ping)
    MManager.register('get_perm_queue', callable=getPermQueue)
    MManager.register('del_perm_queue', callable=delPermQueue)
    MManager.register('get_temp_queue', callable=getTempQueue)
    MManager.register('get_qmanager', callable=QManager)
    m = MManager(address=(host, port), authkey=tools.SERVER_UID.encode('utf-8'))
    s = m.get_server()

    tools.pprint('QDealer: ... is listening on host/port: %s/%s' % (host, str(port)) )
    
    s.serve_forever()
    

                                                #-----------



def getUsage():
    return """
usage: %prog [options]
"""

if __name__ == '__main__':
    from optparse import OptionParser
    import sys
    OG_STDOUT = sys.stdout

    parser = OptionParser(getUsage())
    parser.add_option("--host", dest="host", default='127.0.0.1', help="host")
    parser.add_option("--port", dest="port", type=int, help="port")
    parser.add_option( "--server_uid", dest="server_uid", help="server_uid")
    parser.add_option("--nostdout", action="store_true", default=False, dest="nostdout", help="Outputs (stderr and stdout) are only directed to the apbserver log and not to the console.")
    parser.add_option("--temp_dir", dest="temp_dir", default=tools.getTempDir(), help="temp dir")
    parser.add_option("--verbose", dest="verbose", type="int", default=0, help="(int>0) verbose level")

    (options, args) = parser.parse_args()

    if len(args) != 0 :parser.error("incorrect number of arguments")

    if not isinstance(options.server_uid, str)  or options.server_uid=='':
        raise excpt.ParallineSystemError('server_uid', 'str', str(options.server_uid), fromClass='Main', fromMethod="main")
    server_uid=str(options.server_uid).decode('iso-8859-1').encode('ascii', 'ignore').strip()

    try:
        main(host=options.host, port=options.port, server_uid=server_uid, nostdout=options.nostdout, temp_dir=options.temp_dir, verbose=options.verbose)
    finally:pass