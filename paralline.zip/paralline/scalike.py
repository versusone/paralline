## This file is part of the Software: paralline.
## This file and paralline are provided under the MIT licence:
## The MIT Licence can be found at: https://tldrlegal.com/license/mit-license#fulltext
## and in the file LICENCE.txt of the current directory of the software.
##
## Copyright (c) 2007-2008, Patrick Germain Placidoux
## All rights reserved.
##
## Permission is hereby granted, free of charge, to any person obtaining a copy
## of this software and associated documentation files (the "Software"), to deal
## in the Software without restriction, including without limitation the rights
## to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
## copies of the Software, and to permit persons to whom the Software is
## furnished to do so, subject to the following conditions:
##
## The above copyright notice and this permission notice shall be included in all
## copies or substantial portions of the Software.
##
## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
## IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
## FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
## AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
## LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
## OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
## SOFTWARE.
##
##  @author: Patrick Germain Placidoux
##  @contact: paralline@gmx.com



"""
This help help(scalike) or help(scalike.sclist).

* -------------------------------------------------------------------------------------------------------------------- *
|                                                    SCALIKE                                                         |
* -------------------------------------------------------------------------------------------------------------------- *

Scalike provides and wraps List Transformation functions in a way Scala or Spark does.

The following Tutorial provides a quick sample for each function.

To obtain help for a specific function, please use this into Python interpreter:
    help(sclist.<funct>) e.g.: help(sclist.map)

Let us open Python interpreter:
>>> from scalike import sclist

1. MAP Funtions:
----------------
- map:
>>> l = sclist("one", "two", "three", "four")
Note same as: sclist(("one", "two", "three", "four")) or sclist(["one", "two", "three", "four"]).
>>> l.map(lambda e:e[2])
['e', 'o', 'e', 'u']

- maps:
l = sclist(1,2,3)
ll = (4,5,6)
lll = (7,8,9)
>>> l.maps(lambda a, b, c:a + b + c, ll, lll)
[12, 15, 18]

- starmap:
>>> l = sclist((1,2,3), (4,5,6), (7,8,9))
>>> l.starmap(lambda a, b, c:a + b + c)
[6, 15, 24]

- foreach:
>>> l = sclist("one", "two", "three", "four")
>>> l.foreach(lambda e: print(e[2]))
e
o
e
u

- flatmap:
>>> l = sclist("one", "two", "three", "four")
>>> l.flatmap(lambda e:list(e))
['o', 'n', 'e', 't', 'w', 'o', 't', 'r', 'e', 'e', 'f', 'o', 'u', 'r']

- filter:
>>> l = sclist("one", "two", "three", "four")
>>> l.filter(lambda e:e.startswith('t'))
['two', 'three']

- dropwhile:
>>> l = sclist("one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve")
>>> l.dropwhile(lambda e:len(e)==3)
['three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve']
>>> l.dropwhile(lambda e:len(e) in (3,4,5))
['eleven', 'twelve']

- takewhile:
>>> l = sclist("one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve")
>>> l.takewhile(lambda e:len(e)==3)
['one', 'two']

- mask:
>>> l = sclist("one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve")
>>> l.mask((2,5,7))
['one', 'two', 'three']
>>> l.mask((False,False,True))
['three']
>>> l.mask((False,False,True, 0, 0, 1, False, True, True))
['three', 'six', 'eight', 'nine']

- distinct:
l = sclist(1, 1, 1, 2, 2, 2, 2, 3, 4, 4, 4, 4, 5, 6, 6, 6, 6, 6, 7, 7, 7, 7, 8, 9)
>>> l.distinct()
[1, 2, 3, 4, 5, 6, 7, 8, 9]

l = sclist(
(0,1,2,3,4,5,0),
(0,1,2,3,4,0,6),
(0,1,2,3,0,5,6),
(0,1,2,0,4,5,6),
(0,1,2,3,4,5,0),
'a', 'a', 'b',
'b', 'b', 'c',
'abcdefg',
'hellofg',
)

>>> l.distinct()
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 4, 0, 6), (0, 1, 2, 3, 0, 5, 6), (0, 1, 2, 0, 4, 5, 6), 'a', 'b', 'c', 'abcdefg', 'hellofg']
>>>
>>> l.distinct(selects=(0,1,2,3,4), force_filter=True)
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 0, 5, 6), (0, 1, 2, 0, 4, 5, 6), 'abcdefg', 'hellofg']
>>> l.distinct(omits=(5,6), force_filter=True)
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 0, 5, 6), (0, 1, 2, 0, 4, 5, 6), 'a', 'b', 'c', 'abcdefg', 'hellofg']
>>>
>>> l.distinct(selects=(5,6), force_filter=True)
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 4, 0, 6), (0, 1, 2, 0, 4, 5, 6), 'hellofg']
>>> l.distinct(omits=(0,1,2,3,4), force_filter=True)
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 4, 0, 6), (0, 1, 2, 0, 4, 5, 6), 'c', 'hellofg']

- distinct2:
>>> l = sclist('a'  ,'b', 'c', 'd')
>>> ll = ('e', 'b', 'd', 'e', 2, 3, 4)

>>> # On itself:
>>> l.distinct2(l)
[]
>>> l.distinct2(ll)
['a', 'c']
>>>

- delcols:
l = sclist(
(0,1,2,3,4,5,0),
(0,1,2,3,4,0,6),
['a', 'b', 'c', 'd', 'e', 'f', 'g'],
)

>>> l.delcols((2,3))
[[0, 1, 4, 5, 0], [0, 1, 4, 0, 6], ['a', 'b', 'e', 'f', 'g']]
>>> l.delcols((2,3), keep=True)
[[2, 3], [2, 3], ['c', 'd']]


2. FIND Functions:
------------------

- find
>>> l
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 4, 0, 6), ['a', 'b', 'c', 'd', 'e', 'f', 'g']]
>>> l.find(lambda e:len(e)> 5)
(0, 1, 2, 3, 4, 5, 0)
>>> l.find(lambda e: 5  in e)
(0, 1, 2, 3, 4, 5, 0)

 - exist or any
>>> l.exist(lambda e: 5  in e)
True
>>>
>>> l.exist(lambda e: 7  in e)
False

- forall or all:
>>> l
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 4, 0, 6), ['a', 'b', 'c', 'd', 'e', 'f', 'g']]
>>> l.forall(lambda e: len(e)>5)
True
>>> l.forall(lambda e: 5 in e)
False


3. SORT Functions:
------------------

- sortl
l = sclist('one', 'four', 'three', 'two')
>>> l.sortl(fct=lambda e:str(e[1]))
['one', 'four', 'three', 'two']
>>>
>>> l.sortl(fct=lambda e:str(e[2]))
['one', 'three', 'two', 'four']
>>>
>>> l.sortl(fct=lambda e:str(e[2]), reverse=True)
['four', 'two', 'one', 'three']

- min
>>> l.min(lambda e: e)
'four'

- max
>>> l.max(lambda e: e)
'two'


4. REDUCE Functions:
--------------------

- reduce:
>>> l = sclist('a', 'b', 'c', 'd')
>>> l.reduce(lambda a, b: a + b)
'abcd'

- foldleft:
>>> l.foldleft('z', lambda a, b: a + b)
'zabcd'
>>>
>>> l.foldleft('', lambda a, b: a + b) # Same as l.reduce()
'abcd'

- foldright:
>>> l.foldright('z', lambda a, b: a + b)
'dcbaz'


5. JOIN Functions:
------------------

- union:
>>> l = sclist('a', 'b', 'c', 'd')
>>> ll = (1,2,3,4)
>>> l.union(ll)
['a', 'b', 'c', 'd', 1, 2, 3, 4]

- intersect:
>>> l = sclist("once upon a time in the east !".split())
>>> l
['once', 'upon', 'a', 'time', 'in', 'the', 'east', '!']
>>> ll = "see you next time and call, me once you are in".split()
>>> l.intersect(ll)
['once', 'time', 'in']

- zip:
>>> l = sclist('a', 'b', 'c')
>>> ll = sclist(1, 2, 3, 4, 5, 6)
>>> l.zip(ll)
[('a', 1), ('b', 2), ('c', 3)]
>>>

- zipl:
>>> l = sclist('a', 'b', 'c')
>>> ll = sclist(1, 2, 3, 4, 5, 6)
>>> l.zipl(ll)
[('a', 1), ('b', 2), ('c', 3), (None, 4), (None, 5), (None, 6)]

- zips:
>>> l = sclist('a', 'b', 'c')
>>> ll = (1, 2, 3, 4, 5, 6)
>>> lll  = ('@', '&')
>>> l.zips(ll, lll)
[('a', 1, '@'), ('b', 2, '&')]

- zipls:
>>> l = sclist('a', 'b', 'c')
>>> ll = (1, 2, 3, 4, 5, 6)
>>> lll  = ('@', '&')
>>> l.zipls(ll, lll)
[('a', 1, '@'), ('b', 2, '&'), ('c', 3, None), (None, 4, None), (None, 5, None), (None, 6, None)]

- index:
>>> l.index()
[(0, 'a'), (1, 'b'), (2, 'c')]

- indice:
>>> l = sclist(('o', 'n', 'e'), ('t', 'w', 'o'), ('t', 'h', 'r', 'e', 'e'))
>>> l.indice()
[[0, 'o', 'n', 'e'], [1, 't', 'w', 'o'], [2, 't', 'h', 'r', 'e', 'e']]

- cartesian:
>>> l = sclist('one', 'two', 'three')
>>> ll = (1, 2)
>>> l.cartesian(ll)
[['one', 1], ['one', 2], ['two', 1], ['two', 2], ['three', 1], ['three', 2]]


6. KEYPAIR Functions:
---------------------

- kvKeys:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvKeys()
['a', 'b', 'c']

- kvValues:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvValues()
[1, 2, 3]

- kvMapKeys:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvMapKeys(lambda e: e*3)
[['aaa', 1], ['bbb', 2], ['ccc', 3]]

- kvMapValues:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvMapValues(lambda e: e*3)
[['a', 3], ['b', 6], ['c', 9]]

- kvFilterKeys:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvFilterKeys(lambda e: e<'c')
[('a', 1), ('b', 2)]

- kvFilterValues:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvFilterValues(lambda e: e>2)
[('c', 3)]

- kvJoin:
l = sclist(('a', 1), ('b', 2), ('c', 3))
ll = [('b', 'two'), ('c', 'three'), ('d', 'four')]
>>> l.kvJoin(ll)
[['b', [2, 'two']], ['c', [3, 'three']]]

- kvJoinLeft:
l = sclist(('a', 1), ('b', 2), ('c', 3))
ll =  [('b', 'two'), ('c', 'three'), ('d', 'four')]
>>> l.kvJoinLeft(ll)
[['a', [1, None]], ['b', [2, 'two']], ['c', [3, 'three']]]

- kvJoinRight:
l = sclist(('a', 1), ('b', 2), ('c', 3))
ll =  [('b', 'two'), ('c', 'three'), ('d', 'four')]
>>> l.kvJoinRight(ll)
[['b', ['two', 2]], ['c', ['three', 3]], ['d', ['four', None]]]

- kvSubstract
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> ll =  sclist(('b', 'two'), ('c', 'three'), ('d', 'four'))
>>> l.kvSubstract(ll)
[['a', 1]]
>>>
>>> ll.kvSubstract(l)
[['d', 'four']]

- kvGroupByKey
>>> l = sclist(('a', 1), ('c', 33),
('c', 333),  ('b', 2), ('c', 3),
('a', 11), ('b', 22), ('c', 3333),
('a', 111)
)

- >>> l.kvGroupByKey()
[('a', [1, 11, 111]), ('c', [33, 333, 3, 3333]), ('b', [2, 22])]
"""



import scexception
import itertools
import collections
import functools
import time
import traceback
import random
random.seed()
from case import *


# ------------- #
# TRACE SUPPORT #
# ------------- #

# TRC_TIME_IT:
# ------------
# If True, Scalike will time up all sclist's functions.
TRC_TIME_IT = True

# TRC_TRACE_BACK_IF_GREATER_THAN:
# -------------------------------
# If the time spent in a function is greater than this value,
# Scalike will trace back the script's lignes, causing this poor performance.
TRC_TRACE_BACK_IF_GREATER_THAN = 0

# TRC_DUMP_FIRST_N_OCCURENCES
# ---------------------------
# When the time spent in a function is greater than: TRC_TRACE_BACK_IF_GREATER_THAN,
# Scalike can use this value to dump a fraction of the running list.
# TRC_DUMP_FIRST_N_OCCURENCES takes pecedence over the others.
# TRC_OUTPUT_DIR should exist !
# Note on dump:
# Scalike will jsonize the portion of the list.
# If you list donnot support json.dumps() dont use it.
TRC_DUMP_FIRST_N_OCCURENCES = 0

# TRC_DUMP_LAST_N_OCCURENCES
# --------------------------
# When the time spent in a function is greater than: TRC_TRACE_BACK_IF_GREATER_THAN,
# Scalike can use this value to dump a fraction of the running list.
# TRC_DUMP_LAST_N_OCCURENCES takes pecedence over TRC_DUMP_ALL_OCCURENCES.
# TRC_OUTPUT_DIR should exist !
# Note on dump:
# -------------
# Scalike will jsonize the portion of the list.
# If you list donnot support json.dumps() dont use it.
TRC_DUMP_LAST_N_OCCURENCES = 0

# TRC_DUMP_ALL_OCCURENCES
# -----------------------
# When the time spent in a function is greater than: TRC_TRACE_BACK_IF_GREATER_THAN,
# Scalike can use this value to dump the running list.
# TRC_OUTPUT_DIR should exist !
# Note on dump:
# -------------
# Scalike will jsonize the portion of the list.
# If you list donnot support json.dumps() dont use it.
TRC_DUMP_ALL_OCCURENCES = False

# TRC_OUTPUT_DIR
# --------------
# Output dir of the dump attributes.
TRC_OUTPUT_DIR = "C:\MY_TEMP_DIR"
# TRC_OUTPUT_DIR = "/tmp/MY_TEMP_DIR"

# TRC_PREFIX
# --------------
# Output dir of the dump attributes.
TRC_PREFIX = None



# ------------#
# Annotations #
# ------------#



class trace:
    def __init__(self, participate=True,
        trc_time_it = None,
        trc_trace_back_if_greater_than = None,
        trc_dump_last_n_occurences = None,
        trc_dump_first_n_occurences = None,
        trc_dump_all_occurences = None,
        trc_output_dir=None):
        selfMethod = '__init__'
        if not isinstance(participate, bool): raise scexception.scParameterTypeException('participate', 'bool', str(participate), fromClass='@trace', fromMethod=selfMethod)
        self.__trc_time_it, self.__trc_trace_back_if_greater_than, self.__trc_dump_first_n_occurences, self.__trc_dump_last_n_occurences, self.__trc_dump_all_occurences, self.__trc_output_dir = trc_time_it, trc_trace_back_if_greater_than, trc_dump_first_n_occurences, trc_dump_last_n_occurences, trc_dump_all_occurences, trc_output_dir
        self.__participate = participate



    def __call__(self, ftrc1324):

        def sc_trace(*args, **keywords):  # Signature de f
            selfMethod = ftrc1324.__name__
            from os import path
            # trc_time_it:
            if self.__trc_time_it==None: self.__trc_time_it = TRC_TIME_IT
            # trc_trace_back_if_greater_than:
            if self.__trc_trace_back_if_greater_than==None: self.__trc_trace_back_if_greater_than = TRC_TRACE_BACK_IF_GREATER_THAN
            # trc_dump_first_n_occurences:
            if self.__trc_dump_first_n_occurences==None: self.__trc_dump_first_n_occurences = TRC_DUMP_FIRST_N_OCCURENCES
            # trc_dump_last_n_occurences:
            if self.__trc_dump_last_n_occurences==None: self.__trc_dump_last_n_occurences = TRC_DUMP_LAST_N_OCCURENCES
            # trc_dump_all_occurences:
            if self.__trc_dump_all_occurences==None: self.__trc_dump_all_occurences = TRC_DUMP_ALL_OCCURENCES
            # trc_output_dir:
            if self.__trc_output_dir==None: self.__trc_output_dir = TRC_OUTPUT_DIR

            if not isinstance(self.__trc_time_it, bool): raise scexception.scParameterTypeException('trc_time_it', 'bool', str(self.__trc_time_it), fromClass='@trace', fromMethod=selfMethod)
            if not isinstance(self.__trc_dump_all_occurences, bool): raise scexception.scParameterTypeException('trc_dump_all_occurences', 'bool', str(self.__trc_dump_all_occurences), fromClass='@trace', fromMethod=selfMethod)
            if not isinstance(self.__trc_trace_back_if_greater_than, int): raise scexception.scParameterTypeException('trc_trace_back_if_greater_than', 'int', str(self.__trc_trace_back_if_greater_than), fromClass='@trace', fromMethod=selfMethod)
            if not isinstance(self.__trc_dump_first_n_occurences, int): raise scexception.scParameterTypeException('trc_dump_first_n_occurences', 'int', str(self.__trc_dump_first_n_occurences), fromClass='@trace', fromMethod=selfMethod)
            if not isinstance(self.__trc_dump_last_n_occurences, int): raise scexception.scParameterTypeException('trc_dump_last_n_occurences', 'int', str(self.__trc_dump_last_n_occurences), fromClass='@trace', fromMethod=selfMethod)
            if self.__trc_output_dir==None:
                if (self.__trc_trace_back_if_greater_than, self.__trc_dump_first_n_occurences, self.__trc_dump_last_n_occurences) != (None, None, None):
                    raise scexception.scParameterException('trc_output_dir', 'Must be provided, when one of trc_trace_back_if_greater_than, trc_dump_first_n_occurences or trc_dump_last_n_occurences is provided !', fromClass='@trace', fromMethod=selfMethod)
            elif not path.isdir(self.__trc_output_dir): raise scexception.scParameterException('trc_output_dir', str((self.__trc_output_dir)) + ', Should be an existing directory !', fromClass='@trace', fromMethod=selfMethod)

            if self.__participate and self.__trc_time_it:t1 = time.time()

            # Call function:
            rets = ftrc1324(*args, **keywords)  # Appel f avec les parms de l'Annotation
            if not (self.__participate and self.__trc_time_it):return rets
            this = args[0]

            from io import StringIO
            from os import path
            import pickle
            sb = StringIO()
            t2=time.time() - t1
            scprint('Scalike/Operation %s, ran in %s secondes' % (selfMethod, t2), level=PRINT_TRACE)
            sb.write('# Dumping (option: {OPTION}) trace for :' + '\n')
            sb.write('# ' + len('Dumping trace for :')*'-' + '\n')
            sb.write('# Scalike/Operation %s, ran in %s secondes\n' % (selfMethod, t2))

            if self.__trc_trace_back_if_greater_than!=0 and t2>self.__trc_trace_back_if_greater_than:
                import json
                ts = self.getTs()
                scprint('Tracing back Function: %s, At TS: %s' % (selfMethod, ts), level = PRINT_TRACE )
                sb.write('# Tracing back Function: %s, At TS: %s\n' % (selfMethod, ts))
                trc = traceback.format_stack()[-2]
                scprint(trc, level = PRINT_TRACE )
                sb.write('# ' + '\n#'.join(trc.split('\n')))
                header = sb.getvalue()

                if self.__trc_dump_all_occurences or (self.__trc_dump_first_n_occurences, self.__trc_dump_last_n_occurences) != (0, 0):
                    if self.__trc_dump_first_n_occurences>0:
                        header = header.replace("{OPTION}", "trc_dump_first_n_occurences: %s" % str(self.__trc_dump_first_n_occurences) )
                        l = this[0:self.__trc_dump_first_n_occurences]
                    elif self.__trc_dump_last_n_occurences>0:
                        header = header.replace("{OPTION}", "trc_dump_last_n_occurences: %s" % str(self.__trc_dump_last_n_occurences) )
                        l = this[self.__trc_dump_last_n_occurences:]
                    elif self.__trc_dump_all_occurences:
                        header = header.replace("{OPTION}", "trc_dump_all_n_occurences: %s" % str(self.__trc_dump_all_occurences) )
                        l=this
                    if TRC_PREFIX != None:prefix = TRC_PREFIX + '.'
                    else:prefix=''

                    try:
                        l = list(l).map(lambda e:json.dumps(e))
                        s = header  + '#\n' + '\n'.join(l)

                        file = path.normpath(self.__trc_output_dir + '/' + prefix + '_' + ts + '.trace')
                        with open(file, 'wb') as outfile:outfile.write(s.encode('utf-8'))
                    except:pass

            return rets

        # Transfert help docstring:
        sc_trace.__module__ = ftrc1324.__module__
        sc_trace.__name__ = ftrc1324.__name__
        sc_trace.__doc__ = ftrc1324.__doc__
        return sc_trace

    @staticmethod
    def getTs():
        import datetime, time
        return datetime.datetime.strftime(datetime.datetime.now(), '%Y%m%d_%Hh%Mmn%Ss_' + str(random.randint(1, 100)))



# ------------ #
# CLASS SCLIST #
# ------------ #

SCLIST_EXCEPT_REGULAR_LIST_METHODS=('append', 'clear', 'copy', 'count', 'extend', 'index', 'insert', 'pop', 'remove', 'reverse', 'sort')



class sclist(list):
    """
sclist wrapper.
A Wrapper on the native Python list to support handy scalike functions
from one place in a scala style.

This help help(scalike) or help(scalike.sclist).

* -------------------------------------------------------------------------------------------------------------------- *
|                                                    SCALIKE                                                         |
* -------------------------------------------------------------------------------------------------------------------- *

Scalike provides and wraps List Transformation functions in a way Scala or Spark does.

The following Tutorial provides a quick sample for each function.

To obtain help for a specific function, please use this into Python interpreter:
    help(sclist.<funct>) e.g.: help(sclist.map)


Let us open Python interpreter:
>>> from scalike import sclist

1. MAP Funtions:
----------------
- map:
>>> l = sclist("one", "two", "three", "four")
Note same as: sclist(("one", "two", "three", "four")) or sclist(["one", "two", "three", "four"]).
>>> l.map(lambda e:e[2])
['e', 'o', 'e', 'u']

- maps:
l = sclist(1,2,3)
ll = (4,5,6)
lll = (7,8,9)
>>> l.maps(lambda a, b, c:a + b + c, ll, lll)
[12, 15, 18]

- starmap:
>>> l = sclist((1,2,3), (4,5,6), (7,8,9))
>>> l.starmap(lambda a, b, c:a + b + c)
[6, 15, 24]

- foreach:
>>> l = sclist("one", "two", "three", "four")
>>> l.foreach(lambda e: print(e[2]))
e
o
e
u

- flatmap:
>>> l = sclist("one", "two", "three", "four")
>>> l.flatmap(lambda e:list(e))
['o', 'n', 'e', 't', 'w', 'o', 't', 'r', 'e', 'e', 'f', 'o', 'u', 'r']

- filter:
>>> l = sclist("one", "two", "three", "four")
>>> l.filter(lambda e:e.startswith('t'))
['two', 'three']

- dropwhile:
>>> l = sclist("one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve")
>>> l.dropwhile(lambda e:len(e)==3)
['three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve']
>>> l.dropwhile(lambda e:len(e) in (3,4,5))
['eleven', 'twelve']

- takewhile:
>>> l = sclist("one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve")
>>> l.takewhile(lambda e:len(e)==3)
['one', 'two']

- mask:
>>> l = sclist("one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve")
>>> l.mask((2,5,7))
['one', 'two', 'three']
>>> l.mask((False,False,True))
['three']
>>> l.mask((False,False,True, 0, 0, 1, False, True, True))
['three', 'six', 'eight', 'nine']

- distinct:
l = sclist(1, 1, 1, 2, 2, 2, 2, 3, 4, 4, 4, 4, 5, 6, 6, 6, 6, 6, 7, 7, 7, 7, 8, 9)
>>> l.distinct()
[1, 2, 3, 4, 5, 6, 7, 8, 9]

l = sclist(
(0,1,2,3,4,5,0),
(0,1,2,3,4,0,6),
(0,1,2,3,0,5,6),
(0,1,2,0,4,5,6),
(0,1,2,3,4,5,0),
'a', 'a', 'b',
'b', 'b', 'c',
'abcdefg',
'hellofg',
)

>>> l.distinct()
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 4, 0, 6), (0, 1, 2, 3, 0, 5, 6), (0, 1, 2, 0, 4, 5, 6), 'a', 'b', 'c', 'abcdefg', 'hellofg']
>>>
>>> l.distinct(selects=(0,1,2,3,4), force_filter=True)
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 0, 5, 6), (0, 1, 2, 0, 4, 5, 6), 'abcdefg', 'hellofg']
>>> l.distinct(omits=(5,6), force_filter=True)
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 0, 5, 6), (0, 1, 2, 0, 4, 5, 6), 'a', 'b', 'c', 'abcdefg', 'hellofg']
>>>
>>> l.distinct(selects=(5,6), force_filter=True)
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 4, 0, 6), (0, 1, 2, 0, 4, 5, 6), 'hellofg']
>>> l.distinct(omits=(0,1,2,3,4), force_filter=True)
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 4, 0, 6), (0, 1, 2, 0, 4, 5, 6), 'c', 'hellofg']

- distinct2:
>>> l = sclist('a'  ,'b', 'c', 'd')
>>> ll = ('e', 'b', 'd', 'e', 2, 3, 4)

>>> # On itself:
>>> l.distinct2(l)
[]
>>> l.distinct2(ll)
['a', 'c']
>>>

- delcols:
l = sclist(
(0,1,2,3,4,5,0),
(0,1,2,3,4,0,6),
['a', 'b', 'c', 'd', 'e', 'f', 'g'],
)

>>> l.delcols((2,3))
[[0, 1, 4, 5, 0], [0, 1, 4, 0, 6], ['a', 'b', 'e', 'f', 'g']]
>>> l.delcols((2,3), keep=True)
[[2, 3], [2, 3], ['c', 'd']]


2. FIND Functions:
------------------

- find
>>> l
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 4, 0, 6), ['a', 'b', 'c', 'd', 'e', 'f', 'g']]
>>> l.find(lambda e:len(e)> 5)
(0, 1, 2, 3, 4, 5, 0)
>>> l.find(lambda e: 5  in e)
(0, 1, 2, 3, 4, 5, 0)

 - exist or any
>>> l.exist(lambda e: 5  in e)
True
>>>
>>> l.exist(lambda e: 7  in e)
False

- forall or all:
>>> l
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 4, 0, 6), ['a', 'b', 'c', 'd', 'e', 'f', 'g']]
>>> l.forall(lambda e: len(e)>5)
True
>>> l.forall(lambda e: 5 in e)
False


3. SORT Functions:
------------------

- sortl
l = sclist('one', 'four', 'three', 'two')
>>> l.sortl(fct=lambda e:str(e[1]))
['one', 'four', 'three', 'two']
>>>
>>> l.sortl(fct=lambda e:str(e[2]))
['one', 'three', 'two', 'four']
>>>
>>> l.sortl(fct=lambda e:str(e[2]), reverse=True)
['four', 'two', 'one', 'three']

- min
>>> l.min(lambda e: e)
'four'

- max
>>> l.max(lambda e: e)
'two'


4. REDUCE Functions:
--------------------

- reduce:
>>> l = sclist('a', 'b', 'c', 'd')
>>> l.reduce(lambda a, b: a + b)
'abcd'

- foldLeft:
>>> l.foldleft('z', lambda a, b: a + b)
'zabcd'
>>>
>>> l.foldleft('', lambda a, b: a + b) # Same as l.reduce()
'abcd'

- foldRight:
>>> l.foldright('z', lambda a, b: a + b)
'dcbaz'


5. JOIN Functions:
------------------

- union:
>>> l = sclist('a', 'b', 'c', 'd')
>>> ll = (1,2,3,4)
>>> l.union(ll)
['a', 'b', 'c', 'd', 1, 2, 3, 4]

- intersect:
>>> l = sclist("once upon a time in the east !".split())
>>> l
['once', 'upon', 'a', 'time', 'in', 'the', 'east', '!']
>>> ll = "see you next time and call, me once you are in".split()
>>> l.intersect(ll)
['once', 'time', 'in']

- zip:
>>> l = sclist('a', 'b', 'c')
>>> ll = sclist(1, 2, 3, 4, 5, 6)
>>> l.zip(ll)
[('a', 1), ('b', 2), ('c', 3)]
>>>

- zipl:
>>> l = sclist('a', 'b', 'c')
>>> ll = sclist(1, 2, 3, 4, 5, 6)
>>> l.zipl(ll)
[('a', 1), ('b', 2), ('c', 3), (None, 4), (None, 5), (None, 6)]

- zips:
>>> l = sclist('a', 'b', 'c')
>>> ll = (1, 2, 3, 4, 5, 6)
>>> lll  = ('@', '&')
>>> l.zips(ll, lll)
[('a', 1, '@'), ('b', 2, '&')]

- zipls:
>>> l = sclist('a', 'b', 'c')
>>> ll = (1, 2, 3, 4, 5, 6)
>>> lll  = ('@', '&')
>>> l.zipls(ll, lll)
[('a', 1, '@'), ('b', 2, '&'), ('c', 3, None), (None, 4, None), (None, 5, None), (None, 6, None)]

- index:
>>> l.index()
[(0, 'a'), (1, 'b'), (2, 'c')]

- indice:
>>> l = sclist(('o', 'n', 'e'), ('t', 'w', 'o'), ('t', 'h', 'r', 'e', 'e'))
>>> l.indice()
[[0, 'o', 'n', 'e'], [1, 't', 'w', 'o'], [2, 't', 'h', 'r', 'e', 'e']]

- cartesian:
>>> l = sclist('one', 'two', 'three')
>>> ll = (1, 2)
>>> l.cartesian(ll)
[['one', 1], ['one', 2], ['two', 1], ['two', 2], ['three', 1], ['three', 2]]


6. KEYPAIR Functions:
---------------------

- kvKeys:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvKeys()
['a', 'b', 'c']

- kvValues:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvValues()
[1, 2, 3]

- kvMapKeys:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvMapKeys(lambda e: e*3)
[['aaa', 1], ['bbb', 2], ['ccc', 3]]

- kvMapValues:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvMapValues(lambda e: e*3)
[['a', 3], ['b', 6], ['c', 9]]

- kvFilterKeys:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvFilterKeys(lambda e: e<'c')
[('a', 1), ('b', 2)]

- kvFilterValues:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvFilterValues(lambda e: e>2)
[('c', 3)]

- kvJoin:
l = sclist(('a', 1), ('b', 2), ('c', 3))
ll = [('b', 'two'), ('c', 'three'), ('d', 'four')]
>>> l.kvJoin(ll)
[['b', [2, 'two']], ['c', [3, 'three']]]

- kvJoinLeft:
l = sclist(('a', 1), ('b', 2), ('c', 3))
ll =  [('b', 'two'), ('c', 'three'), ('d', 'four')]
>>> l.kvJoinLeft(ll)
[['a', [1, None]], ['b', [2, 'two']], ['c', [3, 'three']]]

- kvJoinRight:
l = sclist(('a', 1), ('b', 2), ('c', 3))
ll =  [('b', 'two'), ('c', 'three'), ('d', 'four')]
>>> l.kvJoinRight(ll)
[['b', ['two', 2]], ['c', ['three', 3]], ['d', ['four', None]]]

- kvSubstract
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> ll =  sclist(('b', 'two'), ('c', 'three'), ('d', 'four'))
>>> l.kvSubstract(ll)
[['a', 1]]
>>>
>>> ll.kvSubstract(l)
[['d', 'four']]

- kvGroupByKey
>>> l = sclist(('a', 1), ('c', 33),
('c', 333),  ('b', 2), ('c', 3),
('a', 11), ('b', 22), ('c', 3333),
('a', 111)
)

- >>> l.kvGroupByKey()
[('a', [1, 11, 111]), ('c', [33, 333, 3, 3333]), ('b', [2, 22])]
    """


    def __init__(self, *args, **keywords):
        if len(keywords)==0 and len(args) > 1:list.__init__(self, args)
        elif len(keywords)==0 and len(args) == 1 and not isinstance(args[0], collections.Iterable):list.__init__(self, args)
        else:list.__init__(self, *args, **keywords)

    """
    ---------------
     | MAP FAMILY |
    ---------------

    Sample custom trace:
    @trace(
        participate=True,
        trc_time_it = True,
        trc_trace_back_if_greater_than = 0,
        trc_dump_last_n_occurences = 0,
        trc_dump_first_n_occurences = 0,
        trc_dump_all_occurences = False
    )
    """

    @trace()
    def map(self, fct, ignore_none=False, force_ignore=False):
        """
Signature: map(fct)
map applies the function fct to each item of the list,
and returns an sclist of fct(item).

:parameter ignore_none: If true,
will disgarde Noe value from the list.

:arg fct : a function, should return something.
Receive an item as unique argument.
:returns an sclist.

ex1: l.map(f1, [1, 2, 3]) returns [f1(1), f1(2), f1(3)]

ex2:
>>> l = sclist("one", "two", "three", "four")
Note same as: sclist(("one", "two", "three", "four")) or sclist(["one", "two", "three", "four"]).
>>> l.map(lambda e:e[2])
['e', 'o', 'e', 'u']
"""
        selfMethod='map'
        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        if not isinstance(ignore_none, (bool)): raise scexception.scParameterTypeException('ignore_none', 'bool', str(ignore_none), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        if not isinstance(force_ignore, (bool)): raise scexception.scParameterTypeException('force_ignore', 'bool', str(force_ignore), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        if not force_ignore and ignore_none:raise scexception.scSystemException('scalike/distinct Using parameter: ignore_none is time consuming to confirm you must set parameter force_ignore=True !', fromClass=self.__class__.__name__, fromMethod=selfMethod)

        if ignore_none and force_ignore:
            l = sclist()

            for e in self:
                e = fct(e)
                if e == None:continue
                l.append(e)
            return l

        else:return sclist( map(fct, self) )

    @trace(participate=True)
    def maps(self, fct, *iterables):
        """
Signature: maps(fct, *iterables)
map applies the function fct to each item of the iterables,
and returns an sclist of fct(item1, item2, itemn, ...).
Same as map but supports more than one iterable.
Take as many arguments as there are iterables.

:arg fct : a function, should return something.
:returns an sclist.
Receive as many item args as they are iterables.
fct must support as many args as they are iterables.

ex1: l.maps(f1, [1, 2, 3], ['a', 'b', 'c'], [True, False, None]) returns [f1(1, 'a', True), f1(2, 'b', False), f1(3, 'c', None)]
Will stop when reach the end of the shortest iterable.

ex2:
l = sclist(1,2,3)
ll = (4,5,6)
lll = (7,8,9)
>>> l.maps(lambda a, b, c:a + b + c, ll, lll)
[12, 15, 18]
"""
        selfMethod='maps'
        for iterable in iterables:
            if not isinstance(iterable, collections.Iterable):raise scexception.scParameterException('iterables', 'iterables of iterable (sclist, tuple, list, ...) expected !', fromClass='sclist', fromMethod=selfMethod)
        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass='sclist', fromMethod=selfMethod)

        return sclist( map(fct, self, *iterables) )

    @trace(participate=True)
    def starmap(self, fct):
        """
Signature: starmap(fct)
Similar as maps but use it when this slist values are
already organized as tuples.
And fct will take as many args as there is per tuple.
:arg fct : a function, should return something.
:returns an sclist.

ex1: l.starmap(f1, [(1, 2, 3), ('a', 'b', 'c')]) returns sclist([f1(1, 2, 3), f('a', 'b', 'c')])
Will stop when reached the shorted iterable.

ex2:
>>> l = sclist((1,2,3), (4,5,6), (7,8,9))
>>> l.starmap(lambda a, b, c:a + b + c)
[6, 15, 24]
        """
        selfMethod='starmap'
        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        return sclist(itertools.starmap(fct, self))

    @trace(participate=True)
    def foreach(self, fct):
        """
Signature: foreach(fct)
foreach applies the function fct to each item of the list,
:arg fct : a function, must NOT return anything.

ex:
>>> l = sclist("one", "two", "three", "four")
>>> l.foreach(lambda e: print(e[2]))
e
o
e
u
"""
        self.map(fct)

    @trace(participate=True)
    def flatmap(self, fct):
        """
Signature: flatmap(fct)
flatMap is the same as map, but fct may return a tuple or a list.
Then each returned list is extended to the resulting list rather than just added.

:arg fct : a function, must return a tuple or a list.

:returns a flatten sclist of the resulting values.

ex:
>>> l = sclist("one", "two", "three", "four")
>>> l.flatmap(lambda e:list(e))
['o', 'n', 'e', 't', 'w', 'o', 't', 'r', 'e', 'e', 'f', 'o', 'u', 'r']
"""
        selfMethod='flatmap'
        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        founds = sclist()

        for e in self:founds.extend(fct(e))
        return founds


    """
    ------------------
     | FILTER FAMILY |
    ------------------
    """
    @trace(participate=True)
    def filter(self, fct):
        """
Signature: filter(fct)
filter applies the function fct to each item of the list.
If fct(<item>) is true, this item is added to the returned list.

:arg fct : a function, must return a boolean: True or False.

:returns an sclist of the item for which fct(<item>) was True.

ex:
>>> l = sclist("one", "two", "three", "four")
>>> l.filter(lambda e:e.startswith('t'))
['two', 'three']
"""
        selfMethod='filter'
        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        return sclist( filter(fct, self) )

    @trace(participate=True)
    def dropwhile(self, fct):
        """
Signature: dropwhile(fct)
dropwhile drop sclist elements as long as fct(e) is True.
And starts returning the list elements that left,
as soon as the predicate becomes False.

:arg fct : a function, must return a boolean: True or False.
:returns an sclist of the item soon as fct(e) has been once false.

ex:
>>> l = sclist("one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve")
>>> l.dropwhile(lambda e:len(e)==3)
['three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve']
>>> l.dropwhile(lambda e:len(e) in (3,4,5))
['eleven', 'twelve']
"""
        selfMethod='dropwhile'
        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        return sclist( itertools.dropwhile(fct, self) )

    @trace(participate=True)
    def takewhile(self, fct):
        """
Signature: takewhile(fct)
takewhile is the opposite of dropwhile.
takewhile drop sclist elements as long as fct(e) is False.
And starts returning the list elements that left,
as soon as the predicate becomes True.

:arg fct : a function, must return a boolean: True or False.
:returns an sclist of the item soon as fct(e) has been once false.

ex:
>>> l = sclist("one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve")
>>> l.takewhile(lambda e:len(e)==3)
['one', 'two']
"""
        selfMethod='takewhile'
        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        return sclist( itertools.takewhile(fct, self) )

    @trace(participate=True)
    def mask(self, selectors):
        """
Signature: mask(fct, selectors)
mask extract the elements which index match the True flag of the selectors.
:returns an sclist of flagged items.
ex:
 l = sclist(('a', 'b', 'c', 'd', 'e'))
 l.mask([0, 1, 1, 0]) returns ('b', 'c')

ex2:
>>> l = sclist("one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve")
>>> l.mask((2,5,7))
['one', 'two', 'three']
>>> l.mask((False,False,True))
['three']
>>> l.mask((False,False,True, 0, 0, 1, False, True, True))
['three', 'six', 'eight', 'nine']
"""
        selfMethod='mask'
        return sclist( itertools.compress(self, selectors) )

    @trace(participate=True)
    def distinct(self, omits = None, selects=None, force_filter=False):
        """
Signature: distinct(omits = None, selects=None, force_filter=False)
distinct returns a list of the items of this list that only appear once.
:parameter omits(int) : a list or tuple of indices to omit for the dictinct comparaison.
If omits is provided selects cannot.
:parameter selects(int) : a list or tuple of indices  to accept for the dictinct comparaison.
If selects is provided omits cannot.

If either omits or selects is used:
    This list should be an sclist of iterables.
    Others elements that are not iterable are ignored !

:return a list of the unique items of the list.

ex:
l = sclist(1, 1, 1, 2, 2, 2, 2, 3, 4, 4, 4, 4, 5, 6, 6, 6, 6, 6, 7, 7, 7, 7, 8, 9)
>>> l.distinct()
[1, 2, 3, 4, 5, 6, 7, 8, 9]

l = sclist(
(0,1,2,3,4,5,0),
(0,1,2,3,4,0,6),
(0,1,2,3,0,5,6),
(0,1,2,0,4,5,6),
(0,1,2,3,4,5,0),
'a', 'a', 'b',
'b', 'b', 'c',
'abcdefg',
'hellofg',
)

>>> l.distinct()
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 4, 0, 6), (0, 1, 2, 3, 0, 5, 6), (0, 1, 2, 0, 4, 5, 6), 'a', 'b', 'c', 'abcdefg', 'hellofg']
>>>
>>> l.distinct(selects=(0,1,2,3,4), force_filter=True)
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 0, 5, 6), (0, 1, 2, 0, 4, 5, 6), 'abcdefg', 'hellofg']
>>> l.distinct(omits=(5,6), force_filter=True)
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 0, 5, 6), (0, 1, 2, 0, 4, 5, 6), 'a', 'b', 'c', 'abcdefg', 'hellofg']
>>>
>>> l.distinct(selects=(5,6), force_filter=True)
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 4, 0, 6), (0, 1, 2, 0, 4, 5, 6), 'hellofg']
>>> l.distinct(omits=(0,1,2,3,4), force_filter=True)
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 4, 0, 6), (0, 1, 2, 0, 4, 5, 6), 'c', 'hellofg']
"""
        selfMethod='distinct'
        if not isinstance(force_filter, (bool)): raise scexception.scParameterTypeException('force_filter', 'bool', str(force_filter), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        if selects!=None:
            if not isinstance(selects, (list, tuple)):raise scexception.scParameterTypeException('selects', 'list/tuple', str(selects), fromClass=self.__class__.__name__, fromMethod=selfMethod)
            for i in selects:
                if not isinstance(i, (int,)): raise scexception.scParameterException('selects', 'Must be a tuple/list of int ! Received: %s (type %s)' % (str(selects), type(selects)), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        if omits!=None:
            if not isinstance(omits, (list, tuple)):raise scexception.scParameterTypeException('omits', 'list/tuple', str(omits), fromClass=self.__class__.__name__, fromMethod=selfMethod)
            for i in omits:
                if not isinstance(i, (int,)): raise scexception.scParameterException('omits', 'Must be a tuple/list of int ! Received: %s (type %s)' % (str(omits), type(omits)), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        if selects!=None and omits!=None:raise scexception.scParameterException('omits/selects', "Only one of omits or selects can be provided ! Not both.", fromClass=self.__class__.__name__, fromMethod=selfMethod)

        if not force_filter and omits:raise scexception.scSystemException('scalike/distinct Using parameter: omits is time consuming to confirm you must set parameter force_filter=True !', fromClass=self.__class__.__name__, fromMethod=selfMethod)
        if not force_filter and selects:raise scexception.scSystemException('scalike/distinct Using parameter: selects is time consuming to confirm you must set parameter force_filter=True !', fromClass=self.__class__.__name__, fromMethod=selfMethod)
        _iterable = collections.Iterable # optimizing
        dct = {}

        if selects!=None:
            max_selects = max(selects) # optimizing
            for e in self:
                if e ==  None or not isinstance(e, _iterable) or (len(e)-1)<max_selects:continue
                """
                keys = []
                for i in selects:
                    try:
                        keys.append(e[i])
                    except:continue
                """
                dct[repr([e[i] for i in selects])] = e


        elif omits!=None:
            max_omits = max(omits) # optimizing
            for e in self:
                if e ==  None or not isinstance(e, _iterable):continue
                """
                keys = []
                for i in range(len(e)):
                    try:
                        if i in omits:continue
                        keys.append(e[i])
                    except:continue
                """

                # if len(keys)==0:continue
                dct[repr([e[i] for i in range(len(e)) if i not in omits])] = e

        else:dct = {repr(e): e for e in self}

        return sclist(dct.values())

    @trace(participate=True)
    def distinct2(self, iterable):
        """
Signature: distinct2(l)
distinct2 returns a list of all the items of this list that are not in list l.

:arg l : an iterable.

:returns  : an sclist.

ex:
>>> l = sclist('a'  ,'b', 'c', 'd')
>>> ll = ('e', 'b', 'd', 'e', 2, 3, 4)

>>> # On itself:
>>> l.distinct2(l)
[]
>>> l.distinct2(ll)
['a', 'c']
>>>
"""
        selfMethod='distinct2'
        if not isinstance(iterable, collections.Iterable):raise scexception.scParameterException('iterables', 'iterable (sclist, tuple, list, ...) expected !', fromClass=self.__class__.__name__, fromMethod=selfMethod)

        return sclist([e for e in self if e not in iterable])

    @trace(participate=True)
    def delcols(self, cols, keep = False):
        """
Signature: delcols(cols, keep = False)
delcols deletes the columns pointed by the cols tuple (or list).
:parameter cols : a list or tuple of index(es) to delete.
:parameter keep : If True, the filtering is reversed and only the columns of cols list are kept.

This list must be a list of iterables.

:returns an sclist.

ex:
l = sclist(
(0,1,2,3,4,5,0),
(0,1,2,3,4,0,6),
['a', 'b', 'c', 'd', 'e', 'f', 'g'],
)

>>> l.delcols((2,3))
[[0, 1, 4, 5, 0], [0, 1, 4, 0, 6], ['a', 'b', 'e', 'f', 'g']]
>>> l.delcols((2,3), keep=True)
[[2, 3], [2, 3], ['c', 'd']]
        """
        selfMethod='delcols'
        founds = sclist()
        if not isinstance(cols, (tuple, list)): raise scexception.scParameterTypeException('cols', 'list/tuple', str(cols), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        if not isinstance(keep, (bool,)): raise scexception.scParameterTypeException('keep', 'bool', str(keep), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        for i in cols:
            if not isinstance(i, (int,)): raise scexception.scParameterException('cols', 'Must be a tuple/list of int ! Received: %s (type %s)' % (str(cols), type(cols)), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        cols = list(cols)
        cols.sort()
        if not keep:cols.reverse()

        if keep:
            for i in range(len(self)):
                e = self[i]
                ll = sclist()

                try:
                    for j in cols:
                        if j>= len(e):continue
                        ll.append(e[j])
                except:
                    if not isinstance(e, collections.Iterable):raise scexception.scSystemException('scalike/indice this must be an sclist of Iterables. Element: %s (type: %s) at index: %s. Is not an Iterable !'% (self[i], type(self[i]), i), fromClass=self.__class__.__name__, fromMethod=selfMethod)
                    raise

                founds.append(ll)

        else:
            for i in range(len(self)):
                e = self[i]
                ll = sclist()

                try:
                    for j in range(len(e)):
                        if j in cols:continue
                        ll.append(e[j])
                except:
                    if not isinstance(e, collections.Iterable):raise scexception.scSystemException('scalike/indice this must be an sclist of Iterables. Element: %s (type: %s) at index: %s. Is not an Iterable !'% (self[i], type(self[i]), i), fromClass=self.__class__.__name__, fromMethod=selfMethod)
                    raise

                founds.append(ll)

        return founds



    """
    ----------------
     | FIND FAMILY |
    ----------------
    """

    @trace(participate=True)
    def find(self, fct):
        """
Signature: find(fct)
find applies the function fct to each item of the list.
If fct(<item>) is true, item is returned, otherwise None.
Just the first valid item is returned.

:arg fct : a function, must return a boolean: True or False.
:returns an item for which fct(<item>) is True.

ex:
l=sclist((0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 4, 0, 6), ['a', 'b', 'c', 'd', 'e', 'f', 'g'])
>>> l.find(lambda e:len(e)> 5)
(0, 1, 2, 3, 4, 5, 0)
>>> l.find(lambda e: 5  in e)
(0, 1, 2, 3, 4, 5, 0)
"""
        selfMethod='find'
        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        for e in self:
            if fct(e):return e

        return False

    @trace(participate=True)
    def exist(self, fct):
        """
Signature: exist(fct)
exist applies the function fct to each item of the list.
If fct(<item>) is true, True is returned, otherwise False.
:arg fct : a function, must return a boolean: True or False.
:returns if an item satisfies fct(<item>) == True, return True.

ex:
>>> l.exist(lambda e: 5  in e)
True
>>>
>>> l.exist(lambda e: 7  in e)
False
"""
        selfMethod='exist'
        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        for e in self:
            if fct(e):return True

        return False

    @trace(participate=True)
    def any(self, fct):
        """
         Method: any is an Alias for method: exist
        """
        selfMethod='any'
        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        return self.exist(fct)

    @trace(participate=True)
    def forall(self, fct):
        """
Signature: forall(fct)
Same as exists except all item of the list must satisfy: fct(<item>) == True,
  otherwise False is returned.
:arg fct : a function, must return a boolean: True or False.
:returns if all items satisfies fct(<item>) == True, return True.

ex:
>>> l
[(0, 1, 2, 3, 4, 5, 0), (0, 1, 2, 3, 4, 0, 6), ['a', 'b', 'c', 'd', 'e', 'f', 'g']]
>>> l.forall(lambda e: len(e)>5)
True
>>> l.forall(lambda e: 5 in e)
False
"""
        selfMethod='forall'
        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        for e in self:
            if not fct(e):return False

        return True

    @trace(participate=True)
    def all(self, fct):
        """
         Method: all is an Alias for method: forall
        """
        selfMethod='all'
        return self.forAll(fct)



    """
    ----------------
     | SORT FAMILY |
    ----------------
    """

    @trace(participate=True)
    def sortl(self, fct=None, reverse=False):
        """
Signature: sortl(fct=None, reverse=False)
Will sort this list using the callable fct to evaluate the value to be sorted.
ex:
>>> l
['ggg', 'hhh', 'JJJ', 'aaa', 'ccc', 'QQQ', 'ddd']
>>> l.sortl()
['JJJ', 'QQQ', 'aaa', 'ccc', 'ddd', 'ggg', 'hhh']
or:
>>> l.sortl(fct=lambda e:e.lower())
['aaa', 'ccc', 'ddd', 'ggg', 'hhh', 'JJJ', 'QQQ']

:returns a sorted sclist.

ex:
l = sclist('one', 'four', 'three', 'two')
>>> l.sortl(fct=lambda e:str(e[1]))
['one', 'four', 'three', 'two']
>>>
>>> l.sortl(fct=lambda e:str(e[2]))
['one', 'three', 'two', 'four']
>>>
>>> l.sortl(fct=lambda e:str(e[2]), reverse=True)
['four', 'two', 'one', 'three']
"""
        selfMethod='sortl'
        if fct==None or not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        return sclist(sorted(self, key=fct, reverse=reverse))

    @trace(participate=True)
    def min(self, fct=None, reverse=False, default=None):
        """
Signature: min(fct=None, reverse=False, default=None)
Will return the shortest value of this list using the callable fct to evaluate the value to be sorted.
If the list is empty default is returned when provided otherwise a ValueError is raised.
:returns a sorted sclist.

ex:
>>> l.min(lambda e: e)
'four'
"""
        selfMethod='min'
        if fct==None or not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        return min(self, key=fct, default=default)

    @trace(participate=True)
    def max(self, fct=None, reverse=False, default=None):
        """
Signature: max(fct=None, reverse=False, default=None)
Will return the largest value of this list using the callable fct to evaluate the value to be sorted.
If the list is empty default is returned when provided otherwise a ValueError is raised.
:returns a sorted sclist.

ex:
>>> l.max(lambda e: e)
'two'
"""
        selfMethod='max'
        if fct==None or not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        return max(self, key=fct, default=default)


    """
    --------------------------
     | REDUCE FAMILY |
    --------------------------
    """

    """
Voir: https://docs.python.org/3/library/functools.html#functools.reduce

 functools.reduce(function, iterable[, initializer])

    Apply function of two arguments cumulatively to the items of sequence,
	from left to right, so as to reduce the sequence to a single value.
	For example, reduce(lambda x, y: x+y, [1, 2, 3, 4, 5]) calculates ((((1+2)+3)+4)+5).
	The left argument, x, is the accumulated value and the right argument, y, is the update value from the sequence.
	If the optional initializer is present, it is placed before the items of the sequence in the calculation,
	and serves as a default when the sequence is empty.
	If initializer is not given and sequence contains only one item, the first item is returned.
"""

    @trace(participate=True)
    def reduce(self, fct):
        """
Signature: reduce(fct)
reduce, reduce the list to a single value.
fct is called for each element of the list from left to rigth.
But instead of receiving only one item, fct receive <item> and <next item>.
e.g.1: list is (a, b, c, d)
First result = fct(a, b) is called,
Then  result = fct(result, b)
Then  result = fct(result, c) and so on.
To resume the result is: fct(fct(fct(a, b), c), d).
    Or:
     fct
     /\
   fct  d
   /\
 fct  c
 /\
a  b

e.g.2:
l = [1, 2, 3, 4, 5])
l.reduce(lambda x, y: x+y) calculates ((((1+2)+3)+4)+5).

If the list contains only one item, this item is returned.

:arg fct : function receives 2 argument, item and next item.

:returns the value of the fct function.

ex:
>>> l = sclist('a', 'b', 'c', 'd')
>>> l.reduce(lambda a, b: a + b)
'abcd'
"""
        selfMethod='reduce'
        return functools.reduce(fct, self)

    @trace(participate=True)
    def foldleft(self, z, fct):
        """
Signature: foldleft(z, fct)
foldleft applies the function fct to each item of the list.
foldleft applies in a recursive way, e.g.: the list is (a, b, c):
    First starts by the left side of the list, applying fct to z, a: result = fct(z, a),
    Then going on to the next element of the list, applying fct to result, b: result = fct(result, b),
    and next one ... applying fct to result, c: result = fct(result, c),
    Then keep on going ...
    To resume the result is: fct(fct(fct(z, a), b), c).
    Or:
     fct
     /\
   fct  c
   /\
 fct  b
 /\
z  a

:arg z: a predicate any python value.
:arg fct: a function.

:returns the result of the function recursively applied to each element of the list from left to righ,
starting by fct(z, a).

ex:
>>> l.foldleft('z', lambda a, b: a + b)
'zabcd'
>>>
>>> l.foldleft('', lambda a, b: a + b) # Same as l.reduce()
'abcd'
"""
        selfMethod='foldleft'
        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        leftarg=z

        for e in self:leftarg = fct(leftarg, e)

        return leftarg

    @trace(participate=True)
    def foldright(self, z, fct):
        """
Signature: foldright(z, fct):
foldright applies the function fct to each item of the list.
foldright applies in a recursive way, e.g.: the list is (a, b, c):
    First starts by the right side of the list, applying fct to c, z: result = fct(c, z),
    Then going on to the next previous element of the list, applying fct to result, b: result = fct(b, result),
    and next previous one ... applying fct to result, c: result = fct(c, result),
    Then keep on going ...
    To resume the result is: fct(a, fct(b, fct(c, z))).
    Or:
     fct
     /\
    a  fct
       /\
      b  fct
         /\
        c  z

:arg z: a predicate any python value.
:arg fct: a function.

:returns the result of the function recursively applied to each element of the list from right to left,
starting by fct(z, a).

ex:
>>> l.foldright('z', lambda a, b: a + b)
'dcbaz'
"""
        selfMethod='foldright'
        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        l = list(self)
        l.reverse()
        rightarg=z

        for e in self:rightarg = fct(e, rightarg)

        return rightarg


    """
    ----------------
     | JOIN FAMILY |
    ----------------
    """

    @trace(participate=True)
    def union(self, iterable):
        """
Signature: union(l):
union Merge this list with another list.

:arg l : an iterable.

:return the list resulting from the addition of these two list: this + l.

ex:
>>> l = sclist('a', 'b', 'c', 'd')
>>> ll = (1,2,3,4)
>>> l.union(ll)
['a', 'b', 'c', 'd', 1, 2, 3, 4]
"""
        selfMethod='union'
        if not isinstance(iterable, collections.Iterable):raise scexception.scParameterException('iterables', 'iterable (sclist, tuple, list, ...) expected !', fromClass=self.__class__.__name__, fromMethod=selfMethod)

        return sclist(itertools.chain(self, iterable))

    @trace(participate=True)
    def intersect(self, iterable):
        """
Signature: intersect(l):
intersect returns a list of all the items this list that are in list l.

:arg l : an iterable.

:returns the list resulting from the intersect of these two list this and l.

ex:
>>> l = sclist("once upon a time in the east !".split())
>>> l
['once', 'upon', 'a', 'time', 'in', 'the', 'east', '!']
>>> ll = "see you next time and call, me once you are in".split()
>>> l.intersect(ll)
['once', 'time', 'in']
"""
        selfMethod="intersect"
        if not isinstance(iterable, collections.Iterable):raise scexception.scParameterException('iterables', 'iterable (sclist, tuple, list, ...) expected !', fromClass=self.__class__.__name__, fromMethod=selfMethod)

        return sclist([e for e in self if e in iterable])

    @trace(participate=True)
    def zip(self, iterable):
        """
Signature: zip(l)
zip returns a list of pairs.
Each element of la is mapped with the element of the same rank from lb.
Zipping stops at the shortest list.
e.g. for:
la = (a, b, c)
lb = (x, y, z)
Results is:
[(a, x),(b, y),(c, z)]

:arg l : an iterable.

:returns a list of la mapped to lb

ex:
>>> l = sclist('a', 'b', 'c')
>>> ll = sclist(1, 2, 3, 4, 5, 6)
>>> l.zip(ll)
[('a', 1), ('b', 2), ('c', 3)]
"""
        selfMethod="zip"
        if not isinstance(iterable, collections.Iterable):raise scexception.scParameterException('iterables', 'iterable (sclist, tuple, list, ...) expected !', fromClass=self.__class__.__name__, fromMethod=selfMethod)

        return sclist(zip(self, iterable))

    @trace(participate=True)
    def zipl(self, iterable):
        """
Signature: zipl(l)
zipl returns a list of pairs.
Each element of la is mapped with the element of the same rank from lb.
e.g. for:
la = (a, b, c)
lb = (x, y, z)
Results is:
[(a, x),(b, y),(c, z)]
Zipping stops at the longuest list, completing by None value.

:arg l : an iterable, must have the same size than this.

:returns a list of la mapped to lb

ex:
>>> l = sclist('a', 'b', 'c')
>>> ll = sclist(1, 2, 3, 4, 5, 6)
>>> l.zipl(ll)
[('a', 1), ('b', 2), ('c', 3), (None, 4), (None, 5), (None, 6)]
"""
        selfMethod="zipl"
        if not isinstance(iterable, collections.Iterable):raise scexception.scParameterException('iterables', 'iterable (sclist, tuple, list, ...) expected !', fromClass=self.__class__.__name__, fromMethod=selfMethod)

        return sclist(itertools.zip_longest(self, iterable))

    @trace(participate=True)
    def zips(self, *iterables):
        """
Signature: zips(*iterables)
zips returns a list of n-th. e.g.: la, lb, lc, ..., ln-th.
Each element of la is mapped with the n-th element of the same rank from lb, lc nad ln-th.
e.g. for:
la = (a, b, c)
lb = (x, y, z)
lc = (1, 2, 3)
Results is:
[(a, x, 1),(b, y, 2),(c, z, 3)]

:arg iterables : one or more lists, must have the same size than this.

:returns a list of la mapped to lb

ex:
>>> l = sclist('a', 'b', 'c')
>>> ll = (1, 2, 3, 4, 5, 6)
>>> lll  = ('@', '&')
>>> l.zips(ll, lll)
[('a', 1, '@'), ('b', 2, '&')]
"""
        selfMethod="zips"
        for iterable in iterables:
            if not isinstance(iterable, collections.Iterable):raise scexception.scParameterException('iterables', 'iterables of iterable (sclist, tuple, list, ...) expected !', fromClass='Main', fromMethod=selfMethod)

        return sclist(zip(self, *iterables))

    @trace(participate=True)
    def zipls(self, *iterables):
        """
Signature: zipls(*iterables)
zipls returns a list of n-th.
Each element of la is mapped with the n-th element of the same rank from lb, lc nad ln-th.
e.g. for:
la = (a, b, c)
lb = (x, y, z)
lc = (1, 2, 3)
Results is:
[(a, x, 1),(b, y, 2),(c, z, 3)]
Zipping stops at the longuest list, completing by None value.

:arg l : a list, must have the same size than this.

:returns a list of la mapped to lb

ex:
>>> l = sclist('a', 'b', 'c')
>>> ll = (1, 2, 3, 4, 5, 6)
>>> lll  = ('@', '&')
>>> l.zipls(ll, lll)
[('a', 1, '@'), ('b', 2, '&'), ('c', 3, None), (None, 4, None), (None, 5, None), (None, 6, None)]
"""
        selfMethod="zipls"
        for iterable in iterables:
            if not isinstance(iterable, collections.Iterable):raise scexception.scParameterException('iterables', 'iterables of iterable (sclist, tuple, list, ...) expected !', fromClass='Main', fromMethod=selfMethod)

        return sclist(itertools.zip_longest(self, *iterables))

    @trace(participate=True)
    def index(self):
        """
Signature: index()
index returns a list of pairs.
Each element this list mapped with its own rank in this list.
e.g. for:
l = (a, b, c)
Results is:
[(0, a),(1, b),(2, c)]

:returns a list of la mapped to lb

ex:
>>> l.index()
[(0, 'a'), (1, 'b'), (2, 'c')]
"""
        return sclist(enumerate(self, start=0))

    @trace(participate=True)
    def indice(self, withString=False):
        """
Signature: indice(withString=False)
This list must be an sclist of iterables.
Each iterable element of this list receive the element index at first position.
e.g. for:
l = [(1, 2, 3), (a, b), (true, false)]
Results is:
l = [[0, 1, 2, 3], [1, a, b], [2, true, false]]

:returns a list

ex:
>>> l = sclist(('o', 'n', 'e'), ('t', 'w', 'o'), ('t', 'h', 'r', 'e', 'e'))
>>> l.indice()
[[0, 'o', 'n', 'e'], [1, 't', 'w', 'o'], [2, 't', 'h', 'r', 'e', 'e']]
"""
        selfMethod="indice"
        founds = sclist()

        for i in range(len(self)):
            try:
                l=sclist(self[i])
                l.insert(0, i)
                founds.append(l)
            except:
                if not isinstance(self[i], collections.Iterable):raise scexception.scSystemException('scalike/indice this must be an sclist of Iterables. Element: %s (type: %s) at index: %s. Is not an Iterable !'% (self[i], type(self[i]), i), fromClass=self.__class__.__name__, fromMethod=selfMethod)
                raise

        return founds

    @trace(participate=True)
    def cartesian(self, iterable):
        """
Signature: cartesian(l)
cartesian returns a list of pairs.
cartesian returns a list of the elements of this list: la mapped with the elements of list: lb.
This list: la is read in its order and each elements of la is mapped with each elements of lb.
So the resulted list is a product of len(la) * len(lb).
e.g. for:
la = (a, b, c, d)
lb = (x, y, z)
Results is:
[(a, x),(a, y),(a, z),
(b, x),(b, b),(b, z),
(c, x),(c, y),(c, z),
(d, x),(d, y),(d, z)]

:arg l : an iterable.

:returns the cartesian list of la * lb

ex:
>>> l = sclist('one', 'two', 'three')
>>> ll = (1, 2)
>>> l.cartesian(ll)
[['one', 1], ['one', 2], ['two', 1], ['two', 2], ['three', 1], ['three', 2]]
"""
        selfMethod="cartesian"
        if not isinstance(iterable, collections.Iterable):raise scexception.scParameterException('iterables', 'iterable (sclist, tuple, list, ...) expected !', fromClass=self.__class__.__name__, fromMethod=selfMethod)
        founds = sclist()

        for ea in self:
            for eb in iterable:
                founds.append([ea, eb])

        return founds


    """
     -----------------------
     | KV Pair list FAMILY |
     -----------------------
    """

    @trace(participate=True)
    def kvKeys(self):
        """
Signature: kvKeys()
This must be an sclist of key/value pairs list (or tuple).
kvKeys returns a list of the key part of each couple.

:return an sclist of the keys.

ex:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvKeys()
['a', 'b', 'c']
"""
        selfMethod='kvKeys'
        founds = sclist()

        try:
            for i in range(len(self)):
                e = self[i]
                founds.append(e[0])
        except:
            if not isinstance(e, (tuple, list)) or len(e)!=2:raise scexception.scParameterException('sclist', 'Expected a a list of kv elements. Each element msut be a key/value pairs tuples (or lists) ! Incorrect element: %s, at index: %s, is not a key/value pairs list or tuple !' % (self[i], i) , fromClass=self.__class__.__name__, fromMethod=selfMethod)
            raise

        return founds

    @trace(participate=True)
    def kvValues(self):
        """
Signature: kvValues()
This must be a list of key/value pairs list (or tuple).
kvKeys returns a list of the value part of each couple.

:return an sclist of the values.

ex:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvValues()
[1, 2, 3]
"""
        selfMethod='kvValues'
        founds = sclist()

        try:
            for i in range(len(self)):
                e = self[i]
                founds.append(e[1])
        except:
            if not isinstance(e, (tuple, list)) or len(e)!=2:raise scexception.scParameterException('sclist', 'Expected a a list of kv elements. Each element msut be a key/value pairs tuples (or lists) ! Incorrect element: %s, at index: %s, is not a key/value pairs list or tuple !' % (self[i], i) , fromClass=self.__class__.__name__, fromMethod=selfMethod)
            raise

        return founds

    @trace(participate=True)
    def kvMapKeys(self, fct):
        """
Signature: kvMapKeys(fct)
This must be an sclist of key/value pairs list (or tuple).
map applies the function fct to each key part of each item of the list.
And returns the new key/value pairs list.

:arg fct : a function, should return something.

:returns an sclist.

ex:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvMapKeys(lambda e: e*3)
[['aaa', 1], ['bbb', 2], ['ccc', 3]]
"""
        selfMethod='kvMapKeys'
        founds = sclist()

        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        founds = sclist()

        try:
            for i in range(len(self)):
                e = self[i]
                founds.append(sclist(fct(e[0]), e[1]))
        except:
            if not isinstance(e, (tuple, list)) or len(e)!=2:raise scexception.scParameterException('sclist', 'Expected a list of key/value pairs tuples (or lists) ! Incorrect element: %s, at index: %s, is not a key/value pairs list or tuple !' % (self[i], i) , fromClass=self.__class__.__name__, fromMethod=selfMethod)
            raise

        return founds

    @trace(participate=True)
    def kvMapValues(self, fct):
        """
Signature: kvMapValues(fct)
This must be a list of key/value pairs list (or tuple).
map applies the function fct to each value part of each item of the list.
And returns the new key/value pairs list.

:arg fct : a function, should return something.

:returns an sclist passed througth the function fct applied to each value part of each pair of the list.

ex:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvMapValues(lambda e: e*3)
[['a', 3], ['b', 6], ['c', 9]]
"""
        selfMethod='kvMapValues'
        founds = sclist()
        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        try:
            for i in range(len(self)):
                e = self[i]
                founds.append(sclist(e[0], fct(e[1])))
        except:
            if not isinstance(e, (tuple, list)) or len(e)!=2:raise scexception.scParameterException('sclist', 'Expected a list of key/value pairs tuples (or lists) ! Incorrect element: %s, at index: %s, is not a key/value pairs list or tuple !' % (self[i], i) , fromClass=self.__class__.__name__, fromMethod=selfMethod)
            raise

        return founds

    @trace(participate=True)
    def kvFilterKeys(self, fct):
        """
Signature: kvFilterKeys(fct)
This must be an sclist of key/value pairs list (or tuple).
filter applies the function fct to each key part of each item of the list.
And returns the new key/value pairs list.

:arg fct : a function, should return something.

:returns the filtered sclist.

ex:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvFilterKeys(lambda e: e<'c')
[('a', 1), ('b', 2)
"""
        selfMethod='kvFilterKeys'
        founds = sclist()
        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        try:
            for i in range(len(self)):
                e = self[i]

                if not fct(e[0]): continue
                founds.append(e)
        except:
            if not isinstance(e, (tuple, list)) or len(e)!=2:raise scexception.scParameterException('sclist', 'Expected a list of key/value pairs tuples (or lists) ! Incorrect element: %s,  at index: %s, is not a key/value pairs list or tuple !' % (self[i], i) , fromClass=self.__class__.__name__, fromMethod=selfMethod)
            raise

        return founds

    @trace(participate=True)
    def kvFilterValues(self, fct):
        """
Signature: kvFilterValues(fct)
This must be an sclist of key/value pairs list (or tuple).
filter applies the function fct to each value part of each item of the list.
And returns the new key/value pairs list.

:arg fct : a function, should return something.

:returns the filtered sclist.

ex:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> l.kvFilterValues(lambda e: e>2)
[('c', 3)]
"""
        selfMethod='kvFilterValues'
        founds = sclist()
        if not callable(fct):raise scexception.scParameterTypeException('fct', 'callable', str(fct), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        try:
            for i in range(len(self)):
                e = self[i]
                if not fct(e[1]): continue
                founds.append(e)
        except:
            if not isinstance(e, (tuple, list)) or len(e)!=2:raise scexception.scParameterException('sclist', 'Expected a list of key/value pairs tuples (or lists) ! Incorrect element: %s,  at index: %s, is not a key/value pairs list or tuple !' % (self[i], i) , fromClass=self.__class__.__name__, fromMethod=selfMethod)
            raise

        return founds

    @trace(participate=True)
    def kvJoin(self, kv_iterable):
        """
Signature: kvJoin(kv_iterable)
This must be an sclist of key/value pairs list.
kv_iterable must be a list of key/value pairs list.
kvJoin join all the key part of each item this list, with the key part of each item of kv_iterable.
The values o the two list are wrapped to a list associated to the key.

Note : if a key appears more than once in one list, it is overwrite by the next key/pair with the same key, within the same list.
  If any your list supports more than one value for one key you should consider to use kvGroupByKey on it first.

:arg l : a key value pairs list.

:returns an sclist of key value pairs.

ex:
l = sclist(('a', 1), ('b', 2), ('c', 3))
ll = [('b', 'two'), ('c', 'three'), ('d', 'four')]
>>> l.kvJoin(ll)
[['b', [2, 'two']], ['c', [3, 'three']]]
"""
        selfMethod='kvJoin'
        founds = sclist()
        if not isinstance(kv_iterable, collections.Iterable):raise scexception.scParameterTypeException('kv_iterables', 'kv_iterable', str(kv_iterable), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        kv_dict = {e[0]:e[1] for e in kv_iterable if len(e) == 2}

        try:
            for i in range(len(self)):
                e = self[i]
                if e[0] in kv_dict:founds.append(sclist( e[0], sclist( e[1], kv_dict[e[0]]) ))
        except:
            if not isinstance(e, (tuple, list)) or len(e)!=2:raise scexception.scParameterException('sclist', 'Expected a list of key/value pairs tuples (or lists) ! Incorrect element: %s,  at index: %s, is not a key/value pairs list or tuple !' % (self[i], i) , fromClass=self.__class__.__name__, fromMethod=selfMethod)
            raise

        return founds

    @trace(participate=True)
    def kvJoinLeft(self, kv_iterable):
        """
Signature: kvJoinLeft(kv_iterable)
This must be an sclist of key/value pairs list.
kv_iterable must be a list of key/value pairs list.
The same as join, but returns all the key of this list.
And the value None for the mapped key that do not exists in list kv_iterable.

Note : if a key appears more than once in one list, it is overwrite by the next key/pair with the same key, within the same list.
  If any your list supports more than one value for one key you should consider to use kvGroupByKey on it first.

:arg l : a key value pairs list.

:returns an sclist of key value pairs.

ex:
l = sclist(('a', 1), ('b', 2), ('c', 3))
ll =  [('b', 'two'), ('c', 'three'), ('d', 'four')]
>>> l.kvJoinLeft(ll)
[['a', [1, None]], ['b', [2, 'two']], ['c', [3, 'three']]]
"""
        selfMethod='kvJoinLeft'
        founds = sclist()
        if not isinstance(kv_iterable, collections.Iterable):raise scexception.scParameterTypeException('kv_iterables', 'kv_iterable', str(kv_iterable), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        kv_dict = {e[0]:e[1] for e in kv_iterable if len(e) == 2}

        try:
            for i in range(len(self)):
                e = self[i]

                if e[0] in kv_dict:founds.append(sclist( e[0], sclist( e[1], kv_dict[e[0]]) ))
                else:founds.append(sclist( e[0], sclist(e[1], None) ))
        except:
            if not isinstance(e, (tuple, list)) or len(e)!=2:raise scexception.scParameterException('sclist', 'Expected a list of key/value pairs tuples (or lists) ! Incorrect element: %s,  at index: %s, is not a key/value pairs list or tuple !' % (self[i], i) , fromClass=self.__class__.__name__, fromMethod=selfMethod)
            raise

        return founds

    @trace(participate=True)
    def kvJoinRight(self, kv_iterable):
        """
Signature: kvJoinRight(kv_iterable)
This must be an sclist of key/value pairs list.
kv_iterable must be a list of key/value pairs list.
The same as join, but returns all the key of this list.
And the value None for the mapped key that do not exists in list kv_iterable.

Note : if a key appears more than once in one list, it is overwrite by the next key/pair with the same key, within the same list.
  If any your list supports more than one value for one key you should consider to use kvGroupByKey on it first.

:arg l : a key value pairs list.

:returns an sclist of key value pairs.

ex:
l = sclist(('a', 1), ('b', 2), ('c', 3))
ll =  [('b', 'two'), ('c', 'three'), ('d', 'four')]
>>> l.kvJoinRight(ll)
[['b', ['two', 2]], ['c', ['three', 3]], ['d', ['four', None]]]
"""
        selfMethod='kvJoinRight'
        founds = sclist()
        if not isinstance(kv_iterable, collections.Iterable):raise scexception.scParameterTypeException('kv_iterables', 'kv_iterable', str(kv_iterable), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        kv_dict = {e[0]:e[1] for e in self if len(e) == 2}

        try:
            for i in range(len(kv_iterable)):
                e = kv_iterable[i]

                if e[0] in kv_dict:founds.append(sclist( e[0], sclist( e[1], kv_dict[e[0]]) ))
                else:founds.append(sclist( e[0], sclist(e[1], None) ))
        except:
            if not isinstance(e, (tuple, list)) or len(e)!=2:raise scexception.scParameterException('sclist', 'kv_iterable: Expected a list of key/value pairs tuples (or lists) ! Incorrect element: %s,  at index: %s, is not a key/value pairs list or tuple !' % (kv_iterable[i], i) , fromClass=self.__class__.__name__, fromMethod=selfMethod)
            raise

        return founds


    @trace(participate=True)
    def kvSubstract(self, kv_iterable):
        """
Signature: kvSubstract(kv_iterable)
This must be an sclist of key/value pairs list.
This and kv_iterable must be an list of key/value pairs list.
kvSubStract returns all the key of this list that do not exist in list kv_iterable.

Note : if a key appears more than once in one list, it is overwrite by the next key/pair with the same key, within the same list.
  If any your list supports more than one value for one key you should consider to use kvGroupByKey on it first.

:arg l : a key value pairs list.

:returns an sclist of a key value pairs.

ex:
>>> l = sclist(('a', 1), ('b', 2), ('c', 3))
>>> ll =  sclist(('b', 'two'), ('c', 'three'), ('d', 'four'))
>>> l.kvSubstract(ll)
[['a', 1]]
>>>
>>> ll.kvSubstract(l)
[['d', 'four']]
"""
        selfMethod='kvSubstract'
        founds = sclist()
        if not isinstance(kv_iterable, collections.Iterable):raise scexception.scParameterTypeException('kv_iterables', 'kv_iterable', str(kv_iterable), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        kv_dict = {e[0]:e[1] for e in kv_iterable if len(e) == 2}

        try:
            for i in range(len(self)):
                e = self[i]

                if e[0] not in kv_dict:founds.append(sclist( e[0], e[1]))
        except:
            if not isinstance(e, (tuple, list)) or len(e)!=2:raise scexception.scParameterException('sclist', 'Expected a list of key/value pairs tuples (or lists) ! Incorrect element: %s,  at index: %s, is not a key/value pairs list or tuple !' % (self[i], i) , fromClass=self.__class__.__name__, fromMethod=selfMethod)
            raise

        return founds

    @trace(participate=True)
    def kvGroupByKey(self):
        """
Signature: kvGroupByKey()
This must be an sclist of key/value pairs list (or tuple).
kvGroupByKey returns all values grouped by key.

Note : you may use kvGroupByKey when your list supports more than one value for one key.
before using kvJoin, kvJoinLeft and kvSubstract.

:returns an sclist of a key value pairs.

ex:
>>> l = sclist(('a', 1), ('c', 33),
('c', 333),  ('b', 2), ('c', 3),
('a', 11), ('b', 22), ('c', 3333),
('a', 111)
)

- >>> l.kvGroupByKey()
[('a', [1, 11, 111]), ('c', [33, 333, 3, 3333]), ('b', [2, 22])]
"""
        selfMethod='kvGroupByKey'
        kv_dict = {}

        try:
            for i in range(len(self)):
                e = self[i]

                if e[0] not in kv_dict:kv_dict[e[0]] = sclist()
                kv_dict[e[0]].append(e[1])
        except:
            if not isinstance(e, (tuple, list)) or len(e)!=2:raise scexception.scParameterException('sclist', 'Expected a list of key/value pairs tuples (or lists) ! Incorrect element: %s,  at index: %s, is not a key/value pairs list or tuple !' % (self[i], i) , fromClass=self.__class__.__name__, fromMethod=selfMethod)
            raise

        return sclist([(k, kv_dict[k]) for k in kv_dict])



# ------------- #
# PRINT SUPPORT #
# ------------- #

PRINT_INFO = 0
PRINT_WARN = 1
PRINT_TRACE = 2
PRINT_ERROR = 3
PRINT_CRITICAL = 5
PRINT_DEBUG = 6

PRINT_LEVELS = {
    PRINT_INFO: 'INFO',
    PRINT_WARN: 'WARN',
    PRINT_TRACE: 'TRACE',
    PRINT_ERROR: 'ERROR',
    PRINT_CRITICAL: 'CRITICAL',
    PRINT_DEBUG: 'DEBUG'
}


def scprint(*args, level=PRINT_INFO):
    _args = [str(arg) for arg in args]
    value = ' '.join(_args).strip()

    if level not in PRINT_LEVELS:raise

    print ("%s %s" % (PRINT_LEVELS[level], value))
