def digest(lines):
    for i in range(len(lines)):
        line = lines[i]
        # print('line: %s > %s' % (i, line))

    return lines
