"""
See scalike on sourceforge for more on sclist functions.
"""

def digest(lines):
	import shlex

	def sh(e):
		try:
			return shlex.split(e) # Not by lambda because of the except management.
		except:
			return None

	# Before shlex:
	# '-, 596.566.91.159 - - [03/Sep/2017:00:01:21 +0200] "POST /some/uri HTTP/1.1" 200 4331 "https://some/other/referer/uri" "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:55.0) Gecko/20100101 Firefox/55.0" TLSv1.2 ECDHE-RSA-AES128-GCM-SHA256\n'
	lines = lines.map(lambda e:sh(e))
	# After Shlex:
	# ['-,', '596.566.91.159', '-', '-', '[03/Sep/2017:00:01:21', '+0200]', 'POST /some/uri HTTP/1.1', '200', '4331', 'https://some/other/referer/uri', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:55.0) Gecko/20100101 Firefox/55.0', 'TLSv1.2',
	# 'ECDHE-RSA-AES128-GCM-SHA256']

	# Remove UnShlexable lines:
	lines = lines.filter(lambda e: e!=None and len(e)==13)

	# Filter: IP, PROTOCOLE and CIPHER
	lines = lines.map(lambda e: [e[1], e[-2], e[-1]])

	# Get rid of useless lines:
	lines = lines.distinct()

	return lines
