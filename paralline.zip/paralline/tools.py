## This file is part of the Software: paralline.
## This file and paralline are provided under the MIT licence:
## The MIT Licence can be found at: https://tldrlegal.com/license/mit-license#fulltext
## and in the file LICENCE.txt of the current directory of the software.
##
## Copyright (c) 2007-2008, Patrick Germain Placidoux
## All rights reserved.
##
## Permission is hereby granted, free of charge, to any person obtaining a copy
## of this software and associated documentation files (the "Software"), to deal
## in the Software without restriction, including without limitation the rights
## to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
## copies of the Software, and to permit persons to whom the Software is
## furnished to do so, subject to the following conditions:
##
## The above copyright notice and this permission notice shall be included in all
## copies or substantial portions of the Software.
##
## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
## IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
## FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
## AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
## LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
## OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
## SOFTWARE.
##
##  @author: Patrick Germain Placidoux
##  @contact: paralline@gmx.com



import ct as CoolTyping
import wk
import excpt
_eval = CoolTyping._eval

import sys, os
PID = str(os.getpid())
import sys
STDOUT=sys.stdout
STDERR=sys.stderr

TEMP_DIR = None
SERVER_UID = None
INSTALL_DIR = None
FILE_SERVER_UID_PREFIX = 'server_uid_'

PRINT_INFO = 0
PRINT_WARN = 1
PRINT_TRACE = 2
PRINT_ERROR = 3
PRINT_CRITICAL = 5
PRINT_DEBUG = 6

PRINT_LEVELS = {
    PRINT_INFO: 'INFO',
    PRINT_WARN: 'WARN',
    PRINT_TRACE: 'TRACE',
    PRINT_ERROR: 'ERROR',
    PRINT_CRITICAL: 'CRITICAL',
    PRINT_DEBUG: 'DEBUG'
}

def init(server_uid):
    global SERVER_UID
    SERVER_UID = server_uid
    getInstallDir()


#######################
## utility fonctions ##
#######################

def str_to_raw(s):
    # Thanks to ndpu: https://stackoverflow.com/questions/21605526/how-to-create-raw-string-from-string-variable-in-python
    raw_map = {8:r'\b', 7:r'\a', 12:r'\f', 10:r'\n', 13:r'\r', 9:r'\t', 11:r'\v'}
    return r''.join(i if ord(i) > 32 else raw_map.get(ord(i), i) for i in s)

def tsprint(message, level=PRINT_INFO, id="-"):
    if level not in PRINT_LEVELS:raise
    import datetime

    print ("%{ts} %{id} -%{level}- %{message}".format(ts=datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d %H:%M:%S'), id = id, level=PRINT_LEVELS[level], message=message ))

def pprint(*args, qlog = None):
    _args = [str(arg) for arg in args]
    value = ' '.join(_args).strip()
    if value == '':return
    from datetime import datetime
    d = datetime.now()

    values = value.strip('\n').split('\n')
    for value in values:
        value = 'TS:' + str(d.year) + "%02i" % d.month + "%02i" % d.day + '-' + "%02i" % d.hour + ':' + "%02i" % d.minute + ':' \
            + "%02i" % d.second + ':' + "%03i" % (d.microsecond / 1000) + ' ' + PID + ' Paralline: ' + value

        if qlog!=None:qlog.put(value + '\n', True)
        else:STDOUT.write(value + '\n')


class ParallineLock:
    def __init__(self):
        import threading
        self.lock = threading.Lock()
        import preferences
        self.timout = preferences.APBLOCK_TIMOUT
        self.slice = preferences.APBLOCK_SLICE

    def acquire(self, resource, nowait=False, timout=0, slice=0):
        selfMethod = 'acquire'
        if isinstance(resource, (str)) == False or resource == "": raise excpt.ParallineParameterTypeError('resource', 'str', str(resource), fromClass=str(self.__class__), fromMethod=selfMethod)

        if isinstance(timout, (int)) == False or timout < 0: raise excpt.ParallineParameterTypeError('timout', 'int', str(timout), fromClass=str(self.__class__), fromMethod=selfMethod)
        if isinstance(slice, (int)) == False or slice < 0: raise excpt.ParallineParameterTypeError('slice', 'int', str(slice), fromClass=str(self.__class__), fromMethod=selfMethod)
        if (timout != 0): self.timout = timout
        if (slice != 0): self.slice = slice
        if self.timout < self.slice: raise excpt.ParallineParameterError('slice', 'slice must be greater than timout', fromClass=str(self.__class__), fromMethod=selfMethod)

        succeed = False

        import math
        max = math.modf(self.timout / self.slice)[1]
        n = 0
        while n < max:
            succeed = self.lock.acquire(0)
            if (succeed): break
            if (nowait): break
            import time
            time.sleep(self.slice)
            n += 1

        if not succeed:raise excpt.ParallineResourceLockError(resource, fromClass=str(self.__class__), fromMethod=selfMethod)

    def release(self):
        self.lock.release()

def generateUId():
    import time
    import random

    id = str(int(time.time()))
    random.seed()
    rand = random.randint(1, 10000)
    id = id + '_' + "%04i" % rand

    return id

genUid = generateUId

class Dummy:pass

def getInstallDir():
    """
    Retreives the Paralline installation directory.
    """
    global INSTALL_DIR
    if INSTALL_DIR!=None:return INSTALL_DIR

    from os import path

    import inspect
    import tools
    c=tools.Dummy()
    p=inspect.getabsfile(c.__class__)
    for i in range(0, 1):p=path.split(p)[0]
    INSTALL_DIR=p

    return INSTALL_DIR



QUEUE_REDIRECT_OUTPUT_TIMEOUT = 10
class RedirectStd:
    PREFIX_SEPARATOR_BEGIN = '>>>'
    PREFIX_SEPARATOR_END = '<<<'
    TIME_GOUP = 5

    def __init__(self, log_file=None, queue_output=None, stdout=None, stderr=None, prefix=None, do_temporise = True):
        import sys, time, os
        from io import StringIO
        self.isAlive = True
        self.__log_file = log_file
        if self.__log_file:self.__log_file = open(self.__log_file, 'ab')
        self.__queue_output = queue_output
        self.__og_stdout = stdout
        self.__og_stderr = stderr
        self.__was_prev_eol = True
        self.__prev_time = time.time()
        if prefix!=None:
            self.__prefix = prefix
            self.__prefix2 = RedirectStd.PREFIX_SEPARATOR_BEGIN + prefix + RedirectStd.PREFIX_SEPARATOR_END
        else:
            self.__prefix = ''
            self.__prefix2 = ''
        self.__sb = StringIO()
        self.__pid = str(os.getpid())
        self.__do_temporise = do_temporise

        sys.stdout = sys.stderr = self

    def getOgStdout(self):
        return self.__og_stdout

    def getOgStderr(self):
        return self.__og_stderr

    def write(self, value):
        if not self.isAlive:return
        import time
        from io import StringIO
        t = time.time()
        delta = t - self.__prev_time
        self.__prev_time = t

        value = value.strip()
        if value == '':return
        from datetime import datetime
        d = datetime.now()
        value = 'TS:' + str(
            d.year) + "%02i" % d.month + "%02i" % d.day + '-' + "%02i" % d.hour + ':' + "%02i" % d.minute + ':' + "%02i" % d.second + ':' + "%03i" % (
            d.microsecond / 1000) + ' ' + self.__pid + ' ' + self.__prefix + ' ' + value + '\n'
        self.__sb.write(value)

        if self.__do_temporise:
            if delta > RedirectStd.TIME_GOUP:
                self.write_file(self.__prefix2 + self.__sb.getvalue())
                self.__sb = StringIO()
        else:
            self.write_file(self.__prefix2 + self.__sb.getvalue())
            self.__sb = StringIO()

    def write_console(self, value):
        self.__og_stdout.write(value)
        self.__og_stdout.flush()

    def write_file(self, value):
        if self.__log_file != None:
            self.__log_file.write(value)
            self.__log_file.flush()
        else:
            try:
                self.__queue_output.put(value, block=True, timeout=QUEUE_REDIRECT_OUTPUT_TIMEOUT)
            except:
                raise

    def shutdown(self):
        if not self.isAlive: return
        self.isAlive = False
        value = self.__sb.getvalue()
        if len(value)>0:self.write_file(self.__prefix2 + value)


def getOsType():
    """
    Returns the os type.
    unix for unixes or
    windows for win32.
    """
    platform='unix'
    import sys
    if sys.platform=='win32':platform='windows'

    return platform

def getTempDir():
    global TEMP_DIR
    if TEMP_DIR!=None:return TEMP_DIR

    if getOsType() == 'unix':TEMP_DIR = '/tmp'
    else:TEMP_DIR = r'C:\Windows\Temp'

    return TEMP_DIR


def getMd5(value):
    from hashlib import md5
    m = md5()

    m.update(value.encode('utf-8'))
    return str(m.hexdigest())

def isHostPortFree(host, port):
    import socket
    try:
        s=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        s.connect((host, port))
        s.close()
    except:pass
    else:raise Exception('Host: %s, Port: %s is already used !' % (host, port))
