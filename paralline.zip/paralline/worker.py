## This file is part of the Software: paralline.
## This file and paralline are provided under the MIT licence:
## The MIT Licence can be found at: https://tldrlegal.com/license/mit-license#fulltext
## and in the file LICENCE.txt of the current directory of the software.
##
## Copyright (c) 2007-2008, Patrick Germain Placidoux
## All rights reserved.
##
## Permission is hereby granted, free of charge, to any person obtaining a copy
## of this software and associated documentation files (the "Software"), to deal
## in the Software without restriction, including without limitation the rights
## to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
## copies of the Software, and to permit persons to whom the Software is
## furnished to do so, subject to the following conditions:
##
## The above copyright notice and this permission notice shall be included in all
## copies or substantial portions of the Software.
##
## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
## IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
## FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
## AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
## LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
## OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
## SOFTWARE.
##
##  @author: Patrick Germain Placidoux
##  @contact: paralline@gmx.com



from queue import Empty, Full
import sys, traceback
import threading
import random
random.seed()
import preferences
import tools
import excpt
import json
import signal
import scalike

from multiprocessing.managers import BaseManager
class QueueManager(BaseManager): pass
QueueManager.register('get_perm_queue')
QueueManager.register('get_temp_queue')

FAKE_SERVER_UID = None
WORKER_MONITOR = None
WORKER_ID = None
QMQ_RESPONSE_TIMEOUT = 120
QUEUE_REQUEST_MONITOR = None
QUEUE_REQUEST_NEW_TASK = None
QUEUE_RESPONSE_OUTPUT= None
QUEUE_RESPONSE_LOG= None

JOB_FUNCTION = None
JOB_LINE_SEPARATOR = None
VERBOSE = 0
WORKER_ABORT_WHEN_FAIL_TO_RUN_ONE_SHUNK = True
OG_STDOUT = sys.stdout

# ---------------------------------------------------------------------------------------------------------------------#
# WORKER MONITOR:                                                                                                      #
# ---------------------------------------------------------------------------------------------------------------------#

class WorkerMonitor(threading.Thread):

    def __init__(self, qdealer):
        threading.Thread.__init__(self)
        self.setName(WORKER_ID)
        # isAlive
        self.__isAlive = True
        self.__qdealer = qdealer

    def getName(self):
        return WORKER_ID

    def run(self):
        selfMethod = 'run'
        prefix = 'Worker:' + self.getName() + '>'
        import sys, traceback
        global JOB_FUNCTION
        global JOB_LINE_SEPARATOR

        if VERBOSE>=20:print ('MonitorThread Entering.')
        print ('Monitor Q Entered and Wait for input.')


        # Main Loop:
        while True and self.isAlive():
            ## -------------------------------------- #
            ## LISTENING TO QUEUE_REQUEST_MONITOR #
            ## -------------------------------------- #
            try:
                try:
                    values = json.loads( QUEUE_REQUEST_MONITOR.get(True, 5) )
                except Empty:continue
                except: raise excpt.QueueRequestMonitorError(
                    prefix + 'An exception occured reading from the Regular Request Queue: this worker is dying ! SubException is:' + str(
                        sys.exc_info()[0]) + ' ' + str(sys.exc_info()[1]) + ' !', fromClass=str(self.__class__),
                    fromMethod=selfMethod)

                if values == 'suicide': break

                ## -------- ##
                ## DISPATCH ##
                ## -------- ##
                action = values['action']
                queue_response = values['queue_response']
                ret = None


                ## ---------- ##
                ## Q Repoonse ##
                ## ---------- ##
                if queue_response != None:

                    # Retreive Response Q:
                    try: del qrq_queue
                    except: pass
                    qrq_queue = self.__qdealer.get_temp_queue(id=queue_response)
                    try: qrq_queue
                    except:
                        qmq = qrq_queue = None
                        raise excpt.QueueResponseMonitorError(
                            prefix + 'Unable to retreive Dynamic Response Queue ! SubException is:' + str(
                                sys.exc_info()[0]) + ' ' + str(sys.exc_info()[1]) + ' !', fromClass=str(self.__class__),
                            fromMethod=selfMethod)

                if not self.isAlive():break


                ## ----------- ##
                ## Run Actions ##
                ## ----------- ##
                # Action CheckUp :
                if action == 'checkUp': # {'action': 'check_out', 'fct': <dill_dumps>, 'line_separator': None, 'queue_response': None, sctraces={}}
                    import dill, base64

                    fct = base64.b64decode(values['fct'])
                    JOB_FUNCTION = dill.loads(fct)
                    JOB_LINE_SEPARATOR = values['line_separator']
                    sctraces = values['sctraces']
                    scalike.TRC_PREFIX = self.getName().split('_')[-1]
                    if sctraces['trc_time_it']!=None: scalike.TRC_TIME_IT = sctraces['trc_time_it']
                    if sctraces['trc_trace_back_if_greater_than']!=None: scalike.TRC_TRACE_BACK_IF_GREATER_THAN = sctraces['trc_trace_back_if_greater_than']
                    if sctraces['trc_dump_first_n_occurences']!=None: scalike.TRC_DUMP_FIRST_N_OCCURENCES = sctraces['trc_dump_first_n_occurences']
                    if sctraces['trc_dump_last_n_occurences']!=None: scalike.TRC_DUMP_LAST_N_OCCURENCES = sctraces['trc_dump_last_n_occurences']
                    if sctraces['trc_dump_all_occurences']!=None: scalike.TRC_DUMP_ALL_OCCURENCES = sctraces['trc_dump_all_occurences']
                    if sctraces['trc_output_dir']!=None: scalike.TRC_OUTPUT_DIR = sctraces['trc_output_dir']

                    if VERBOSE>20:print ('Monitor Q/Action: received Action Checkup, Funtion: %s' % JOB_FUNCTION.__name__)
                    ret = 1


                else: pass

                ## -------- ##
                ## RESPONSE ##
                ## -------- ##

                if queue_response != None:
                    try:
                        qrq_queue.put(ret, True)
                        qmq = qrq_queue = None
                    except:
                        qmq = qrq_queue = None
                        raise excpt.QueueResponseMonitorError(
                            prefix + 'Unable to Put response value to dynamic Response Queue ! SubException is:' + str(
                                sys.exc_info()[0]) + ' ' + str(sys.exc_info()[1]) + ' !', fromClass=str(self.__class__),
                            fromMethod=selfMethod)

            ## ----------------------- ##
            ## Global Error Management ##
            ## ----------------------- ##
            except:
                traceback.print_exc(sys.exc_info())
                self.shutdown()
                continue

        ## ---- ##
        ## Exit ##
        ## ---- ##


        if VERBOSE>20:print ('Monitor Q loop Leaving on Terminate.')
        self.shutdown()

    def isAlive(self):
        return self.__isAlive

    def shutdown(self):
        self.__isAlive = False


# ---------------------------------------------------------------------------------------------------------------------#
# Signal Handler:                                                                                                      #
# ---------------------------------------------------------------------------------------------------------------------#

def signal_handler(signal, frame):
    WORKER_MONITOR.shutdown()
    WORKER_MONITOR.join()

    import sys
    sys.exit()

try:signal.signal(signal.SIGUSR1, signal_handler)
except:
    try: signal.signal(signal.SIGTERM, signal_handler)
    except:pass


# ---------------------------------------------------------------------------------------------------------------------#
# Main:                                                                                                                #
# ---------------------------------------------------------------------------------------------------------------------#

def main(server_uid=None, worker_id=None, queue_request_monitor_id=None, queue_request_new_task_id=None, queue_response_output_id=None, queue_response_log_id=None, qd_host=None, qd_port=None, nostdout=False):
    selfMethod = 'main'
    global QUEUE_REQUEST_MONITOR, QUEUE_REQUEST_NEW_TASK, QUEUE_RESPONSE_OUTPUT, QUEUE_RESPONSE_LOG
    global FAKE_SERVER_UID
    global WORKER_ID
    global WORKER
    from os import path
    import sys
    from os import remove

    # -- server_uid:
    file_server_uid = path.normpath(preferences.TEMP_DIR + '/' + server_uid + '.dat')
    fd = open(file_server_uid, 'rb')
    server_uid = fd.read().decode('utf-8')
    fd.close()
    remove(file_server_uid)
    FAKE_SERVER_UID = tools.getMd5(server_uid)
    tools.init(server_uid)

    # -- Acces to Global QManager:
    qdealer = QueueManager(address=(qd_host, qd_port), authkey=tools.SERVER_UID.encode('utf-8'))
    qdealer.connect()

    # -- Init globals vars:
    WORKER_ID = FAKE_SERVER_UID + '_' + worker_id
    dct = {'queue_request_monitor': queue_request_monitor_id,
        'queue_request_new_task': queue_request_new_task_id,
        'queue_response_output': queue_response_output_id,
        'queue_response_log': queue_response_log_id
    }
    for queue_id in dct:
        globals()[queue_id.upper()] = qdealer.get_temp_queue(id=dct[queue_id])
        try: globals()[queue_id.upper()]
        except:
            globals()[queue_id.upper()] = None
            raise Exception('Worker:' + WORKER_ID + ': Unable to retreive queue:' + queue_id + ' !')


    # -- Redirects Logs:
    redirect = tools.RedirectStd(log_file=None, queue_output=QUEUE_RESPONSE_LOG, stdout=sys.stdout, stderr=sys.stderr, prefix=worker_id, do_temporise=True)

    # -- Run Worker Monitor:
    WORKER_MONITOR = WorkerMonitor(qdealer)
    WORKER_MONITOR.start()

    """
    # -------------------#
    |  Running Task Loop |
    # -----------------------------------------------------------------------------------------------------------------#
    """

    ## ----------------------------------- #
    ## LISTENING TO QUEUE_REQUEST_NEW_TASK #
    ## ----------------------------------- #

    while True and WORKER_MONITOR.isAlive():
        try:
            payload = QUEUE_REQUEST_NEW_TASK.get(True, 60)
        except Empty:continue
        except: raise excpt.QueueRequestNewTaskError(
            'An exception occured reading from the Regular Request Queue: this worker is dying ! SubException is:' + str(
                sys.exc_info()[0]) + ' ' + str(sys.exc_info()[1]) + ' !', fromClass='main',
            fromMethod=selfMethod)

        if payload == 0:
            QUEUE_RESPONSE_OUTPUT.put(0, True) # Free Reader
            break

        shunks = json.loads(payload)
        print("<-- Got new Payload [Entering]\n")
        input_lines = []


        ## -------- ##
        ## DISPATCH ##
        ## -------- ##

        for shunk in shunks: # {'file': file, 'begin': begin, 'end': end}

            print("Gathering Shunk Index: %s, on File: %s, StartsAt: %s, EndsAt: %s\n" % (shunk['shunk_index'], shunk['file'], shunk['begin'], shunk['end']))
            fd = open(shunk['file'], 'rb')
            fd.seek(shunk['begin'])
            s = fd.read(shunk['end'] - shunk['begin']).decode('utf-8')
            fd.close()

            lines = s.strip(JOB_LINE_SEPARATOR).split(JOB_LINE_SEPARATOR)
            if s.endswith(JOB_LINE_SEPARATOR):lines.append('')

            input_lines.extend(lines)

        ## -------- ##
        ## RUN TASK ##
        ## -------- ##
        try:
            print("<- Starting Function: %s on Payload (Entering)\n" % JOB_FUNCTION.__name__)
            output_lines = JOB_FUNCTION(scalike.sclist(input_lines))
            print("Function Succeed !")
        except:
            trace_back = traceback.format_exc()
            # traceback.print_exc(sys.exc_info()) : stuck Paralline

            print ('Exception: UserFunctionError> ' + str(
                excpt.UserFunctionError(
                'An exception occured running the function %s, this worker is dying ! SubException is: %s !' %
                (JOB_FUNCTION.__name__, str(sys.exc_info()[0].__name__) + ' ' + str(sys.exc_info()[1]) ),
                fromClass='main', fromMethod=selfMethod) ) )

            msg = 'TraceBack:'
            print(msg)
            print(len(msg)*'-')
            print(trace_back)

            print('Function Failed !')

            if WORKER_ABORT_WHEN_FAIL_TO_RUN_ONE_SHUNK:
                QUEUE_RESPONSE_OUTPUT.put(1, True) # Free Reader
                break
            else:continue

        finally:
            print("-> Starting Function: %s on Payload (Leaving)\n" % JOB_FUNCTION.__name__)
            print("--> Got new Payload [Leaving]\n")

        ## ---------------- ##
        ## DUMP TASK OUTPUT ##
        ## ---------------- ##

        if output_lines!=None:QUEUE_RESPONSE_OUTPUT.put(output_lines, True)

    print("Worker Ended !")
    redirect.shutdown()
    WORKER_MONITOR.shutdown()
    WORKER_MONITOR.join()




# ---------------------------------------------------------------------------------------------------------------------#
# Options:                                                                                                             #
# ---------------------------------------------------------------------------------------------------------------------#

def getUsage():
    return """
usage: %prog [options]
"""

if __name__ == '__main__':
    from optparse import OptionParser

    parser = OptionParser(getUsage())
    parser.add_option("--server_uid", dest="server_uid", help="server_uid")
    parser.add_option("--worker_id", dest="worker_id", help="worker_id")
    parser.add_option("--queue_request_monitor_id", dest="queue_request_monitor_id", help="queue_request_monitor_id")
    parser.add_option("--queue_request_new_task_id", dest="queue_request_new_task_id", help="queue_request_new_task_id")
    parser.add_option("--queue_response_output_id", dest="queue_response_output_id", help="queue_response_output_id")
    parser.add_option("--queue_response_log_id", dest="queue_response_log_id", help="queue_response_log_id")
    parser.add_option("--qd_host", dest="qd_host", help="queue dealer Host")
    parser.add_option("--qd_port", dest="qd_port", type=int, help="queue dealer Port")
    parser.add_option("--abort_when_fail_to_run_one_shunk", action="store_true", default=False, dest="worker_abort_when_fail_to_run_one_shunk")
    parser.add_option("--temp_dir", dest="temp_dir", default=tools.getTempDir(), help="temp dir")
    parser.add_option("-v", "--verbose", dest="verbose", type=int, default=0, help="(int>0) verbose level.")
    parser.add_option("--nostdout", action="store_true", default=False, dest="nostdout",
        help="Outputs (stderr and stdout) are only directed to the worker log and not to the console.")

    (options, args) = parser.parse_args()
    if len(args) != 0: parser.error("incorrect number of arguments:" + str(args) + ' ! Worker do not support any argument.')
    preferences.TEMP_DIR = tools.TEMP_DIR = options.temp_dir
    VERBOSE = options.verbose
    WORKER_ABORT_WHEN_FAIL_TO_RUN_ONE_SHUNK = options.worker_abort_when_fail_to_run_one_shunk

    for option in ('server_uid', 'worker_id', 'queue_request_monitor_id', 'queue_request_new_task_id', 'queue_response_output_id', 'queue_response_log_id'):
        if not isinstance(getattr(options, option), str) or getattr(options, option) == '':
            raise excpt.WorkerSystemError(option, 'str', str(getattr(options, option)), fromClass='Main', fromMethod="main")

    for option in ('server_uid', 'worker_id', 'queue_request_monitor_id', 'queue_request_new_task_id', 'queue_response_output_id', 'queue_response_log_id'):
        setattr(options, option, str(getattr(options, option)).encode('utf-8').decode('utf8', 'ignore').strip())

    main(server_uid=options.server_uid, worker_id=options.worker_id,
        queue_request_monitor_id=options.queue_request_monitor_id,
        queue_request_new_task_id=options.queue_request_new_task_id,
        queue_response_output_id=options.queue_response_output_id,
        queue_response_log_id=options.queue_response_log_id,
         qd_host=options.qd_host, qd_port=options.qd_port, nostdout = options.nostdout)
