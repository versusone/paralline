## This file is part of the Software: paralline.
## This file and paralline are provided under the MIT licence:
## The MIT Licence can be found at: https://tldrlegal.com/license/mit-license#fulltext
## and in the file LICENCE.txt of the current directory of the software.
##
## Copyright (c) 2007-2008, Patrick Germain Placidoux
## All rights reserved.
##
## Permission is hereby granted, free of charge, to any person obtaining a copy
## of this software and associated documentation files (the "Software"), to deal
## in the Software without restriction, including without limitation the rights
## to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
## copies of the Software, and to permit persons to whom the Software is
## furnished to do so, subject to the following conditions:
##
## The above copyright notice and this permission notice shall be included in all
## copies or substantial portions of the Software.
##
## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
## IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
## FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
## AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
## LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
## OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
## SOFTWARE.
##
##  @author: Patrick Germain Placidoux
##  @contact: paralline@gmx.com


import threading
import tools
import excpt



"""
===========
| WORKERS |
===========
"""



class WorkersPool:

    def __init__(self, qdealer = None, server_uid = None, fct = None, line_separator = None, qd_host = None, qd_port = None, proc_parallele = None, queue_response_log = None, abort_when_fail_to_launch_one_worker=False, worker_abort_when_fail_to_run_one_shunk=False, sctraces=None, temp_dir=None, verbose = 0):

        self.__qdealer, self.__server_uid, self.fct, self.line_separator, self.__qd_host, self.__qd_port, self.__sctraces = qdealer, server_uid, fct, line_separator, qd_host, qd_port, sctraces
        self.__abort_when_fail_to_launch_one_worker = abort_when_fail_to_launch_one_worker
        self.__worker_abort_when_fail_to_run_one_shunk = worker_abort_when_fail_to_run_one_shunk
        self.__proc_parallele  = proc_parallele
        self.__pool = {}
        self.__pool_lock = tools.ParallineLock()
        self.__queue_response_log = queue_response_log
        self.__queue_response_log_id = queue_response_log.qmq_getId()
        self.__temp_dir = temp_dir
        self.__verbose = verbose
        self.newWorkers()
        self.__joinWorkers()

    def getQDealer(self):
        return self.__qdealer

    def getPool(self):
        return dict(self.__pool)

    def newWorkers(self):
        selfMethod='newWorkers'
        nb_workers=self.__proc_parallele - len(self.__pool)

        if self.__verbose>10:
            msg = '\nWorkerManager: %s, Launching: %s, Worker Processes.' % ( self.__class__.__name__, str(nb_workers))
            tools.pprint(msg + '\n' + len(msg)*'-', qlog = self.__queue_response_log)

        for index in range(nb_workers):
            # queue_request_monitor :
            queue_request_monitor = self.__qdealer.get_temp_queue()
            try:queue_request_monitor
            except:
                queue_request_monitor=None
                raise excpt.ParallineSystemError('Unable to retreive queue_request_monitor !', fromClass=self.__class__.__name__, fromMethod=selfMethod)

            # queue_request_new_task :
            queue_request_new_task = self.__qdealer.get_temp_queue()
            try:queue_request_new_task
            except:
                queue_request_new_task=None
                raise excpt.ParallineSystemError('Unable to retreive queue_request_new_task !', fromClass=self.__class__.__name__, fromMethod=selfMethod)

            # queue_response_output :
            queue_response_output = self.__qdealer.get_temp_queue()
            try:queue_response_output
            except:
                queue_response_output=None
                raise excpt.ParallineSystemError('Unable to retreive queue_request_output !', fromClass=self.__class__.__name__, fromMethod=selfMethod)

            name = 'w' + str(index)
            process=self.__launchProcessWorker(name, queue_request_monitor_id=queue_request_monitor.qmq_getId(), queue_request_new_task_id=queue_request_new_task.qmq_getId(), queue_response_output_id=queue_response_output.qmq_getId(), nostdout=False)
            w=Worker(self, index, name, process=process, queue_request_monitor=queue_request_monitor, queue_request_new_task=queue_request_new_task, queue_response_output=queue_response_output, sctraces=self.__sctraces)

            self.__pool[index]=w
            w.start()

    def __launchProcessWorker(self, worker_id, queue_request_monitor_id=None, queue_request_new_task_id=None, queue_response_output_id=None, nostdout=False):
        from os import path
        import subprocess, sys
        bin=path.normpath(tools.INSTALL_DIR + '/worker.py')

        if tools.getOsType() == 'windows':
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags = subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = subprocess.SW_HIDE
        else:startupinfo = None

        if self.__verbose>10:tools.pprint('\nWorkerManager:' + self.__class__.__name__ + ': Launching Worker Processes:', worker_id, qlog = self.__queue_response_log)

        # Protect server_uid into external temp file, soon destroyed. A001:
        file_server_uid=tools.FILE_SERVER_UID_PREFIX + tools.genUid()
        fd=open(path.normpath(self.__temp_dir + '/' + file_server_uid + '.dat'), 'wb')
        fd.write(self.__server_uid.encode('utf-8'))
        fd.close()

        parms=[  sys.executable, bin, '--server_uid', file_server_uid, '--worker_id', worker_id, '--qd_host', self.__qd_host, '--qd_port', str(self.__qd_port), '--queue_request_monitor_id', queue_request_monitor_id, '--queue_request_new_task_id', queue_request_new_task_id, '--queue_response_output_id', queue_response_output_id, '--queue_response_log', self.__queue_response_log_id, '--temp_dir', self.__temp_dir, '--verbose', str(self.__verbose) ]
        if self.__worker_abort_when_fail_to_run_one_shunk:parms.append('--abort_when_fail_to_run_one_shunk')
        if nostdout:parms.append('--nostdout')

        if self.__verbose>50:tools.pprint('\nWorkerManager:' + self.__class__.__name__ + ': Launching Worker Processes:', worker_id, ' '.join(parms), qlog = self.__queue_response_log)

        process = subprocess.Popen(parms, startupinfo=startupinfo)

        return process

    def __joinWorkers(self):
        selfMethod='__joinWorkers'
        pool_size = len(self.__pool)
        pool_keys = list(self.__pool.keys())
        pool_keys.sort()
        for key in pool_keys:
            if key not in self.__pool:continue
            w = self.__pool[key]
            w.join(10)
            if w.is_alive() or w.failed:
                mes = 'Unable to Launch Worker: %s ! Expected Pool size: %s. Real Pool size: %s. You may consider to change the configuration parameter: abort_when_fail_to_launch_one_worker.' % (w.getName(), pool_size, len(self.__pool))
                if self.__abort_when_fail_to_launch_one_worker:
                    raise excpt.ParallineSystemError(mes, fromClass=self.__class__.__name__, fromMethod=selfMethod)
                else:
                    tools.pprint(mes, len(self.__pool), qlog = self.__queue_response_log)
                w.suicide()

    def removeWorker(self, w):
        self.__pool_lock.acquire('worker pool')

        try:
            if w.getIndex() in self.__pool:del self.__pool[w.getIndex()]
        except:raise
        finally:self.__pool_lock.release()

        if self.__verbose>10:tools.pprint('\nWorkerManager: Removed Worker ==> ', len(self.__pool), qlog = self.__queue_response_log)

    def getRealWorkerCount(self):
        return len(self.__pool)

    def getQResponseOutPuts(self):
        pool_keys = list(self.__pool.keys())
        pool_keys.sort()

        return [self.__pool[key].getQResponseOutput() for key in pool_keys]

    def join(self):
        import warnings
        from time import sleep

        pool_keys = list(self.__pool.keys())
        pool_keys.sort()

        while len(pool_keys)!=0:
            for proc_index in pool_keys:
                worker = pool_keys[proc_index]
                process = worker.getProcess()
                process.communicate()

                returncode = process.poll()

                if returncode!=None:
                    self.removeWorker(worker)
                    if returncode<0:pass
                    elif (returncode!=0):warnings.warn("Process: %s ended with Bad Status: %s !" % (proc_index, returncode))

                sleep(2)
            pool_keys = list(self.__pool.keys())
            pool_keys.sort()


class Worker(threading.Thread):
    def __init__(self, pool, index, name, process=None, queue_request_monitor=None, queue_request_new_task=None, queue_response_output=None, sctraces=None):
        threading.Thread.__init__(self, None, None, name)
        self.__sctraces = sctraces
        self.__pool=pool
        self.__qdealer = pool.getQDealer()
        self.__index=index
        self.__process=process

        self.__queues={'queue_request_monitor': queue_request_monitor, 'queue_request_new_task': queue_request_new_task, 'queue_response_output': queue_response_output}
        self.__queue_request_monitor=queue_request_monitor
        self.__queue_request_new_task=queue_request_new_task
        self.__queue_response_output=queue_response_output
        self.__queue_response_output.worker_name = self.getName()
        self.failed = False

    def run(self):
        import json
        import dill, base64
        try:
            # queue_response:
            queue_response = self.__qdealer.get_temp_queue()
            queue_response

            # Put :
            fct = base64.b64encode(dill.dumps(self.__pool.fct)).decode('utf-8')
            self.getQMonitor().put(json.dumps({'action': 'checkUp', 'fct': fct, 'line_separator': self.__pool.line_separator, 'queue_response': queue_response.qmq_getId(), 'sctraces': self.__sctraces}), True)

            # Response :
            value = queue_response.get(True, 5)
            if value!=1:raise
        except:
            import sys, traceback
            traceback.print_exc(file=sys.stdout)
            self.suicide()
            self.failed = True
            raise excpt.ParallineSystemError('Unable to Launch Worker: %s !' % self.getName() + '. SubException:' + str(sys.exc_info()[0]) + ' ' + str(sys.exc_info()[1]), fromClass=self.__class__.__name__, fromMethod="main")

    def getIndex(self):
        return self.__index

    def getQMonitor(self):
        return self.__queue_request_monitor

    def getQRequestNewTask(self):
        return self.__queue_request_new_task

    def getQResponseOutput(self):
        return self.__queue_response_output

    def getQueues(self):
        return dict(self.__queues)

    def getProcess(self):
        return self.__process

    def isAlive(self):
        if self.__process.poll()==None:return True
        else:return False

    def suicide(self):
        import signal

        if hasattr(signal, 'SIGUSR1'):self.__process.send_signal(signal.SIGUSR1)
        # elif hasattr(signal, 'SIGBREAK'):self.__process.send_signal(signal.SIGBREAK)
        elif hasattr(signal, 'SIGTERM'):self.__process.send_signal(signal.SIGTERM)
        else:self.__process.terminate()

        self.__pool.removeWorker(self)

